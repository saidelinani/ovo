package ma.eai.devbq.ovfgapel.asal;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "detail")
public class AsalOutput {

	private String codeGuichet;
	private String codeSas;
	private String nom;
	private String prenom;
	
	public String getCodeGuichet() {
		return codeGuichet;
	}
	public void setCodeGuichet(String codeGuichet) {
		this.codeGuichet = codeGuichet;
	}
	public String getCodeSas() {
		return codeSas;
	}
	public void setCodeSas(String codeSas) {
		this.codeSas = codeSas;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	
}
