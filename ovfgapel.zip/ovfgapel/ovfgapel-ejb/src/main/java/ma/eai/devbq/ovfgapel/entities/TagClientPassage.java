package ma.eai.devbq.ovfgapel.entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the TAG_CLIENT_PASSAGE database table.
 * 
 */
@Entity
@Table(name="TAG_CLIENT_PASSAGE")
@NamedQuery(name="TagClientPassage.findAll", query="SELECT t FROM TagClientPassage t")
public class TagClientPassage implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_CLIENT_PASSAGE_IDCLIENTPASSAGE_GENERATOR", sequenceName="SEQUENCE_TAG_CLIENT_PASSAGE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_CLIENT_PASSAGE_IDCLIENTPASSAGE_GENERATOR")
	@Column(name="ID_CLIENT_PASSAGE")
	private long idClientPassage;

	@Column(name="CODE_POSTAL")
	private String codePostal;

	@Column(name="CODE_PROFESSION")
	private String codeProfession;

	@Column(name="DATE_DELIVRANCE")
	private String dateDelivrance;

	@Column(name="DATE_NAISSANCE")
	private String dateNaissance;

	@Column(name="NATIONALITE")
	private String nationalite;

	@Column(name="NOM")
	private String nom;

	@Column(name="NUMERO_PI")
	private String numeroPi;

	@Column(name="PAYS")
	private String pays;

	@Column(name="PRENOM")
	private String prenom;

	@Column(name="SITE")
	private String site;

	@Column(name="TYPE_PI")
	private String typePi;

	@Column(name="VILLE_EMISSION")
	private String villeEmission;

	public TagClientPassage() {
	}

	public long getIdClientPassage() {
		return this.idClientPassage;
	}

	public void setIdClientPassage(long idClientPassage) {
		this.idClientPassage = idClientPassage;
	}

	public String getCodePostal() {
		return this.codePostal;
	}

	public void setCodePostal(String codePostal) {
		this.codePostal = codePostal;
	}

	public String getCodeProfession() {
		return this.codeProfession;
	}

	public void setCodeProfession(String codeProfession) {
		this.codeProfession = codeProfession;
	}

	public String getDateDelivrance() {
		return this.dateDelivrance;
	}

	public void setDateDelivrance(String dateDelivrance) {
		this.dateDelivrance = dateDelivrance;
	}

	public String getDateNaissance() {
		return this.dateNaissance;
	}

	public void setDateNaissance(String dateNaissance) {
		this.dateNaissance = dateNaissance;
	}

	public String getNationalite() {
		return this.nationalite;
	}

	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}

	public String getNom() {
		return this.nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getNumeroPi() {
		return this.numeroPi;
	}

	public void setNumeroPi(String numeroPi) {
		this.numeroPi = numeroPi;
	}

	public String getPays() {
		return this.pays;
	}

	public void setPays(String pays) {
		this.pays = pays;
	}

	public String getPrenom() {
		return this.prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getSite() {
		return this.site;
	}

	public void setSite(String site) {
		this.site = site;
	}

	public String getTypePi() {
		return this.typePi;
	}

	public void setTypePi(String typePi) {
		this.typePi = typePi;
	}

	public String getVilleEmission() {
		return this.villeEmission;
	}

	public void setVilleEmission(String villeEmission) {
		this.villeEmission = villeEmission;
	}

}