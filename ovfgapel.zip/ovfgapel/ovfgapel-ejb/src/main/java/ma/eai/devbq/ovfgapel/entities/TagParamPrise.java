package ma.eai.devbq.ovfgapel.entities;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TAG_PARAM_PRISE database table.
 * 
 */
@Entity
@Table(name="TAG_PARAM_PRISE")
@NamedQuery(name="TagParamPrise.findAll", query="SELECT t FROM TagParamPrise t")
public class TagParamPrise implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_PARAM_PRISE_IDPARAM_GENERATOR", sequenceName="SEQUENCE_TAG_PARAM_PRISE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_PARAM_PRISE_IDPARAM_GENERATOR")
	@Column(name="ID_PARAM")
	private String idParam;

	@Column(name="DESCRIPTION")
	private String description;

	@Column(name="SOP")
	private String sop;

	@Column(name="VALEUR")
	private String valeur;

	public TagParamPrise() {
	}

	public String getIdParam() {
		return this.idParam;
	}

	public void setIdParam(String idParam) {
		this.idParam = idParam;
	}

	public String getDescription() {
		return this.description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSop() {
		return this.sop;
	}

	public void setSop(String sop) {
		this.sop = sop;
	}

	public String getValeur() {
		return this.valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}

}