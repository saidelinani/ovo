package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author ghanemel
 */

public class AsalException extends Exception {

    private String code;

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public AsalException() {
	super();
    }

    public AsalException(String message) {
	super(message);
    }

    public AsalException(String message, String code) {
	super(message);
	this.code = code;
    }

    public AsalException(Throwable cause) {
	super(cause);
    }

    public AsalException(String message, Throwable cause) {
	super(message, cause);
    }

}
