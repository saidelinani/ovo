package ma.eai.devbq.ovfgapel.xmlmapping;

import ma.eai.devbq.tools.CompteBancaire;

/**
 *
 * @author GHANEM
 */
public class FluxEntree {

    private String codFonc;
    private String mntOpe;
    private String codPopsPrd;
    private CompteBancaire ribDor;
    private String codDevOpe;// COD_DEV_OPE;
    private String ideRibDor; //IDE_RIB_DOR;
    private String devRibDor; //DEV_RIB_DOR;
    private String refTieDorCnc; //REF_TIE_DOR_CNC;
    private String refTieDor; //REF_TIE_DOR;
    private String typCtlRis; // TYP_CTL_RIS;
    private String ctlSasDmd; //CTL_SAS_DMD;
    private String codOpe; //COD_OPE;
    private String sptOpe; //SPT_OPE;
    private String typOpe; //TYP_OPE;
    private String numTieDorCnc; //NUM_TIE_DOR_CNC;
    private String numTieDor; //NUM_TIE_DOR;
    private String nomDor; //NOM_DOR;
    private String ctgCpt; //CAT_CPT;
// MAJ Solde OVO
    private String evtSopEmet; // EVT_SOP_EMET;
    

	private String evtUtilLge; //EVT_UTI_LGE;
    private String evtUtiPhy; // EVT_UTI_PHY;
    private String eveCodBq; //EVE_COD_BQ;
    private String eveCodCai; //EVE_COD_CAI;
    private String eveCodEntRat; //EVE_COD_ENT_RAT;
    private String evtRefOpe; //EVT_REF_OPE;
    private String evtStatut; //EVT_STATUT;
    private String evtDateHeu; //EVT_DATE_HEU;
    private String evtMod; //EVT_MOD;
    private String refBlcInt; // REF_BLC_INT;
    
    // RCP
    private String flagCltPsg; // FLAG_CLT_PSG 

    /*
     * Agence du CC :
	ajouté après déploiement SY le 01/10/2012, pour résolution du problème de CC inexistant sur l'agence du client
	après son déplacement ou par exemple suite à un transfert de compte
    */

    private String agenceCc ; //AGENCE_CC

    public String getCodDevOpe() {
	return codDevOpe;
    }

    public void setCodDevOpe(String codDevOpe) {
	this.codDevOpe = codDevOpe;
    }

    public String getCodFonc() {
	return codFonc;
    }

    public void setCodFonc(String codFonc) {
	this.codFonc = codFonc;
    }

    public String getCodOpe() {
	return codOpe;
    }

    public void setCodOpe(String codOpe) {
	this.codOpe = codOpe;
    }

    public String getCodPopsPrd() {
	return codPopsPrd;
    }

    public void setCodPopsPrd(String codPopsPrd) {
	this.codPopsPrd = codPopsPrd;
    }

    public String getCtlSasDmd() {
	return ctlSasDmd;
    }

    public void setCtlSasDmd(String ctlSasDmd) {
	this.ctlSasDmd = ctlSasDmd;
    }

    public String getDevRibDor() {
	return devRibDor;
    }

    public void setDevRibDor(String devRibDor) {
	this.devRibDor = devRibDor;
    }

    public String getEveCodBq() {
	return eveCodBq;
    }

    public void setEveCodBq(String eveCodBq) {
	this.eveCodBq = eveCodBq;
    }

    public String getEveCodCai() {
	return eveCodCai;
    }

    public void setEveCodCai(String eveCodCai) {
	this.eveCodCai = eveCodCai;
    }

    public String getEveCodEntRat() {
	return eveCodEntRat;
    }

    public void setEveCodEntRat(String eveCodEntRat) {
	this.eveCodEntRat = eveCodEntRat;
    }

    public String getEvtDateHeu() {
	return evtDateHeu;
    }

    public void setEvtDateHeu(String evtDateHeu) {
	this.evtDateHeu = evtDateHeu;
    }

    public String getEvtMod() {
	return evtMod;
    }

    public void setEvtMod(String evtMod) {
	this.evtMod = evtMod;
    }

    public String getEvtRefOpe() {
	return evtRefOpe;
    }

    public void setEvtRefOpe(String evtRefOpe) {
	this.evtRefOpe = evtRefOpe;
    }

    public String getEvtSopEmet() {
	return evtSopEmet;
    }

    public void setEvtSopEmet(String evtSopEmet) {
	this.evtSopEmet = evtSopEmet;
    }

    public String getEvtStatut() {
	return evtStatut;
    }

    public void setEvtStatut(String evtStatut) {
	this.evtStatut = evtStatut;
    }

    public String getEvtUtiPhy() {
	return evtUtiPhy;
    }

    public void setEvtUtiPhy(String evtUtiPhy) {
	this.evtUtiPhy = evtUtiPhy;
    }

    public String getEvtUtilLge() {
	return evtUtilLge;
    }

    public void setEvtUtilLge(String evtUtilLge) {
	this.evtUtilLge = evtUtilLge;
    }

    public String getIdeRibDor() {
	return ideRibDor;
    }

    public void setIdeRibDor(String ideRibDor) {
	this.ideRibDor = ideRibDor;
    }

    public String getMntOpe() {
	return mntOpe;
    }

    public void setMntOpe(String mntOpe) {
	this.mntOpe = mntOpe;
    }

    public String getNomDor() {
	return nomDor;
    }

    public void setNomDor(String nomDor) {
	this.nomDor = nomDor;
    }

    public String getNumTieDor() {
	return numTieDor;
    }

    public void setNumTieDor(String numTieDor) {
	this.numTieDor = numTieDor;
    }

    public String getNumTieDorCnc() {
	return numTieDorCnc;
    }

    public void setNumTieDorCnc(String numTieDorCnc) {
	this.numTieDorCnc = numTieDorCnc;
    }

    public String getRefBlcInt() {
	return refBlcInt;
    }

    public void setRefBlcInt(String refBlcInt) {
	this.refBlcInt = refBlcInt;
    }

    public String getRefTieDor() {
	return refTieDor;
    }

    public void setRefTieDor(String refTieDor) {
	this.refTieDor = refTieDor;
    }

    public String getRefTieDorCnc() {
	return refTieDorCnc;
    }

    public void setRefTieDorCnc(String refTieDorCnc) {
	this.refTieDorCnc = refTieDorCnc;
    }

    public CompteBancaire getRibDor() {
	return ribDor;
    }

    public void setRibDor(CompteBancaire ribDor) {
	this.ribDor = ribDor;
    }

    public String getSptOpe() {
	return sptOpe;
    }

    public void setSptOpe(String sptOpe) {
	this.sptOpe = sptOpe;
    }

    public String getTypCtlRis() {
	return typCtlRis;
    }

    public void setTypCtlRis(String typCtlRis) {
	this.typCtlRis = typCtlRis;
    }

    public String getTypOpe() {
	return typOpe;
    }

    public void setTypOpe(String typOpe) {
	this.typOpe = typOpe;
    }

    public String getAgenceCc() {
	return agenceCc;
    }

    public void setAgenceCc(String agenceCc) {
	this.agenceCc = agenceCc;
    }
    public String getCtgCpt() {
		return ctgCpt;
	}

	public void setCtgCpt(String ctgCpt) {
		this.ctgCpt = ctgCpt;
	}

	public String getFlagCltPsg() {
		return flagCltPsg;
	}

	public void setFlagCltPsg(String flagCltPsg) {
		this.flagCltPsg = flagCltPsg;
	}
    
}
