package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author ghanemel
 */

public class SoumissionException extends Exception {

    private String codeErreur;
    private String messageErreur;

    public String getCodeErreur() {
	return codeErreur;
    }

    public void setCodeErreur(String codeErreur, String msg) {
	this.codeErreur = codeErreur;
	this.messageErreur = msg;
    }

    public String getMessageErreur() {
	return messageErreur;
    }

    public void setMessageErreur(String messageErreur) {
	this.messageErreur = messageErreur;
    }

    public SoumissionException() {
	super();
    }

    public SoumissionException(String message) {
	super(message);
    }

    public SoumissionException(String code, String message) {
	super(message);
	this.codeErreur = code;
	this.messageErreur = message;
    }

    public SoumissionException(Throwable cause) {
	super(cause);
    }

    public SoumissionException(String message, Throwable cause) {
	super(message, cause);
    }

}
