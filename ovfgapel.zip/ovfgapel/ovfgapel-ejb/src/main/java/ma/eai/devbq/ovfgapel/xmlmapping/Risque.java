package ma.eai.devbq.ovfgapel.xmlmapping;

/**
 * Classe des differents risques
 * 
 */
public class Risque {

    private String staRis;
    private String famRis;
    private String typRis;
    private String ssTypRis;
    private String ribRis;
    private String seuFlt;
    private String seuVld;
    private String ifrRis;
    private String libRis;

    public Risque(String type) {
        init(type);
    }

    private void init(String type) {
        this.ribRis = "DOR";
        this.famRis = "CCLTR";
        this.seuFlt = "";
        this.seuVld = "";
        this.ssTypRis = "";
        this.typRis = "TCCLR";
        this.staRis = "B";

        if (type.equals("NON_CONTX")) {
            this.famRis = "CONTX";
            this.libRis = "Compte non contentieux !";
            this.ifrRis = "Le Compte n'est pas en contentieux !";
            return;
        }

        if (type.equals("CLOTURE-B")) {
            this.libRis = "Compte cloturé par la banque!";
            this.ifrRis = "Compte cloturé par la banque!";
            return;
        }

        if (type.equals("CLOTURE-C")) {
            this.libRis = "Compte cloturé par le client!";
            this.ifrRis = "Compte cloturé par le client!";
            return;
        }

        if (type.equals("CLOTURE")) {
            this.libRis = "Compte cloturé !";
            this.ifrRis = "Compte cloturé !";
            return;
        }

        if (type.equals("CLOTURE-D")) {
            this.libRis = "Compte en déshérence !";
            this.ifrRis = "Compte en déshérence !";
            return;
        }

        if (type.equals("TRANSFERE")) {
            this.libRis = "Compte transféré !";
            this.ifrRis = "Compte transféré !";
            return;
        }

        if (type.equals("COMPROMIS")) {
            this.famRis = "CONTX";
            this.libRis = "Compte en compromis !";
            this.ifrRis = "Compte en compromis !";
            this.typRis = "BLCON";
            return;
        }

        if (type.equals("COMPTE-BLOQUE")) {
            this.famRis = "TRGUI";
            this.libRis = "Compte bloqué  !";
            this.ifrRis = "Compte bloqué  !";
            this.typRis = "BLATD";
            return;
        }

        if (type.equals("DECES")) {
            this.famRis = "DECES";
            this.libRis = "Client Décédé !";
            this.ifrRis = "Le compte correspond à un client Décédé !";
            this.typRis = "DECES";
            return;
        }

        this.typRis = "BLATD";
        if (type.equals("SAISIE-ARRET")) {
            this.famRis = "TRGUI";
            this.libRis = "Compte en saisie arrêt !";
            this.ifrRis = "Compte en saisie arrêt !";
            return;
        }

        if (type.equals("COMPTE-BLOQUE")) {
            this.famRis = "TRGUI";
            this.libRis = "Compte bloqué  !";
            this.ifrRis = this.libRis;
            return;
        }

        this.famRis = "DECAI";
        this.typRis = "DECAI";
        this.libRis = "Provision insuffisante !";

        if (type.equals("PROVISION-INSUFFISANTE")) {
            this.ifrRis = "Provision insuffisante !";
            this.staRis = "S";
            return;
        } 
        
        if (type.equals("DEPASSEMENT-30000")) {
            this.libRis = "Retrait Dépassant 30 000 Dhs  !";
            this.ifrRis = "Le montant de retrait dépasse 30 000 Dhs !";
            this.staRis = "S";
            return;
        }
        
        if (type.equals("DEPASSEMENT-RCG")) {
            this.libRis = "Retrait Dépassant 30 000 Dhs  !";
            this.ifrRis = "Le montant du chèque dépasse 30 000 Dhs !";
            this.staRis = "S";
            return;
        }
        
        if (type.equals("PROVISION-INSUFFISANTE-B")) {
            this.ifrRis = "Provision insuffisante et agence non migrée !";
            return;
        }
        
        if (type.equals("PROVISION-INSUFFISANTE-REA")) {
            this.ifrRis = "Provision insuffisante pour retrait effet avalisé!";
            return;
        }
        
        if (type.equals("PROVISION-INSUFFISANTE-CSC")) {
            this.ifrRis = "Provision insuffisante pour compte sur carnet !";
            return;
        }
        
        if (type.equals("OPERATION-NON-AUTORISEE")) {
            this.famRis = "FRAUD";
            this.libRis = "Veuillez effectuer ces opérations au niveau du REGLEMENT FACTURE «AUTRES SOCIETES»";
            this.ifrRis = "Veuillez effectuer ces opérations au niveau du REGLEMENT FACTURE «AUTRES SOCIETES»";
            this.typRis = "NAUTO";
        }
        
        if (type.equals("OPERATION-NON-AUTORISEE-CNSS")) {
            this.famRis = "FRAUD";
            this.libRis = "Veuillez effectuer cette opération au niveau du REGLEMENT FACTURE «CNSS»";
            this.ifrRis = "Veuillez effectuer cette opération au niveau du REGLEMENT FACTURE «CNSS»";
            this.typRis = "NAUTO";
        }

        if (type.equals("OPERATION-FACT-PORTNET-NON-AUTORISEE")) {
            this.famRis = "FRAUD";
            this.libRis = "Versement non autorisé via le Canal TAG";
            this.ifrRis = "Versement non autorisé via le Canal TAG";
            this.typRis = "NAUTO";
        }

        if (type.equals("OPERATION-NON-AUTORISEE-MDJS")) {
            this.famRis = "FRAUD";
            this.libRis = "Versement non autorisé via le Canal TAG";
            this.ifrRis = "Versement non autorisé via le Canal TAG";
            this.typRis = "NAUTO";
        }
        if (type.equals("OPERATION-NON-AUTORISEE-HYPOTHECA")) {
            this.famRis = "FRAUD";
            this.libRis = "Versement non autorisé via le Canal TAG";
            this.ifrRis = "Versement non autorisé via le Canal TAG";
            this.typRis = "NAUTO";
        }
        if (type.equals("OPERATION-NON-AUTORISEE-REMEDIAL-MAGAGEMENT")) {
            this.famRis = "FRAUD";
            this.libRis = "Merci de passer par opération VINCLI en saisissant le compte client contentieux";
            this.ifrRis = "Merci de passer par opération VINCLI en saisissant le compte client contentieux";
            this.typRis = "NAUTO";
        }
    }

    public String getFamRis() {
        return famRis;
    }

    public void setFamRis(String famRis) {
        this.famRis = famRis;
    }

    public String getIfrRis() {
        return ifrRis;
    }

    public void setIfrRis(String ifrRis) {
        this.ifrRis = ifrRis;
    }

    public String getLibRis() {
        return libRis;
    }

    public void setLibRis(String libRis) {
        this.libRis = libRis;
    }

    public String getRibRis() {
        return ribRis;
    }

    public void setRibRis(String ribRis) {
        this.ribRis = ribRis;
    }

    public String getSeuFlt() {
        return seuFlt;
    }

    public void setSeuFlt(String seuFlt) {
        this.seuFlt = seuFlt;
    }

    public String getSeuVld() {
        return seuVld;
    }

    public void setSeuVld(String seuVld) {
        this.seuVld = seuVld;
    }

    public String getSsTypRis() {
        return ssTypRis;
    }

    public void setSsTypRis(String ssTypRis) {
        this.ssTypRis = ssTypRis;
    }

    public String getStaRis() {
        return staRis;
    }

    public void setStaRis(String staRis) {
        this.staRis = staRis;
    }

    public String getTypRis() {
        return typRis;
    }

    public void setTypRis(String typRis) {
        this.typRis = typRis;
    }

    @Override
    public String toString() {

        return "staRis   =" + staRis + "\n"
                + "famRis   =" + famRis + "\n"
                + "typRis   =" + typRis + "\n"
                + "ssTypRis =" + ssTypRis + "\n"
                + "ribRis   =" + ribRis + "\n"
                + "seuFlt   =" + seuFlt + "\n"
                + "seuVld   =" + seuVld + "\n"
                + "ifrRis   =" + ifrRis + "\n"
                + "libRis   =" + libRis + "\n";

    }

}
