package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author ghanemel 
 */
public class ServiceSoldeException extends Exception {

    private String codeErreur;
    private String messageErreur;

    public String getCodeErreur() {
	return codeErreur;
    }

    public void setCodeErreur(String codeErreur, String msg) {
	this.codeErreur = codeErreur;
	this.messageErreur = msg;
    }

    public String getMessageErreur() {
	return messageErreur;
    }

    public void setMessageErreur(String messageErreur) {
	this.messageErreur = messageErreur;
    }

    public ServiceSoldeException() {
	super();
    }

    public ServiceSoldeException(String message) {
	super(message);
    }

    public ServiceSoldeException(String code, String message) {
	super(message);
	this.codeErreur = code;
	this.messageErreur = message;
    }

    public ServiceSoldeException(Throwable cause) {
	super(cause);
    }

    public ServiceSoldeException(String message, Throwable cause) {
	super(message, cause);
    }
    
}
