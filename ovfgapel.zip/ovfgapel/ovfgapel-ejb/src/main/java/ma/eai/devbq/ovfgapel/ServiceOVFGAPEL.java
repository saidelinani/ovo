package ma.eai.devbq.ovfgapel;

/**
 *
 * @author GHANEM
 */
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Remote;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.sql.DataSource;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.ParsingException;
import ma.eai.devbq.ovfgapel.constantes.CodeFonction;
import ma.eai.devbq.ovfgapel.constantes.CodeRetour;
import ma.eai.devbq.ovfgapel.dao.IDaoOvfgapel;
import ma.eai.devbq.ovfgapel.entities.TagTypeOperation;
import ma.eai.devbq.ovfgapel.exceptions.AsalException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceOVOException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceOVOInaccessible;
import ma.eai.devbq.ovfgapel.exceptions.ServiceSoldeException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceSoldeInaccessible;
import ma.eai.devbq.ovfgapel.exceptions.ServiceTagException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceTagInaccessible;
import ma.eai.devbq.ovfgapel.exceptions.SoumissionException;
import ma.eai.devbq.ovfgapel.exceptions.TacheEcouteException;
import ma.eai.devbq.ovfgapel.services.ControleRisques;
import ma.eai.devbq.ovfgapel.services.ControleRisques2;
import ma.eai.devbq.ovfgapel.services.MajAnnulSoldeOVO;
import ma.eai.devbq.ovfgapel.services.SoumissionOVO;
import ma.eai.devbq.ovfgapel.services.SoumissionRep;
import ma.eai.devbq.ovfgapel.xmlmapping.FluxEntree;
import ma.eai.devbq.ovfgapel.xmlmapping.FluxSortie;
import ma.eai.devbq.ovfgapel.xmlmapping.Risque;
import ma.eai.devbq.tools.CompteBancaire;
import ma.eai.devbq.tools.CompteIncorrectException;
import ma.eai.devbq.tools.Outils;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.log.Log;
import ma.eai.refCpt.exeception.FormatNumcompteInvalideException;

@Stateless(mappedName = "ejb/ServiceOvfgapel")
@TransactionAttribute(TransactionAttributeType.REQUIRED)
@Remote(ma.eai.midw.connectors.SynchroneService.class)
public class ServiceOVFGAPEL implements SynchroneService {

    private transient String idFonction;
    @Resource(name = "jdbc/DCXADSTAG", authenticationType = Resource.AuthenticationType.CONTAINER)
    private static DataSource dataCenterDs;
    @Resource(name = "jdbc/DWHDSXA", authenticationType = Resource.AuthenticationType.CONTAINER)
    private static DataSource dataWarehouseDs;
    
    @EJB(mappedName = "ejblocal:ejb/daoOvfgapel")
    private IDaoOvfgapel dao;
    
    @Resource
    private static SessionContext sctx; 
    private FluxEntree fluxEntree;
    private FluxSortie fluxSortie;
    //private ControleRisques controleRisques;
    private ControleRisques2 controleRisques;
    private MajAnnulSoldeOVO majSoldeOVO;
    private SoumissionOVO soumissionOVO;
    private SoumissionRep soumissionRep;
    private String racineRetour;
    private int comsommateurService = 0;
    private static final String CloseL = "</L>";
    private String codeFonc;
    
    public static List<TagTypeOperation> listTypeOeration = new ArrayList<TagTypeOperation>();

    @PostConstruct
    public void initilisation() {

		Log.info("Initialisation des sous services");
		Log.info("Lancement du sous service ControleRisque");
	
		//controleRisques = new ControleRisques(dataCenterDs, dataWarehouseDs);
		controleRisques = new ControleRisques2(dataCenterDs, dataWarehouseDs);
		Log.info("Sous service ControleRisque lancé");
	
		soumissionOVO = new SoumissionOVO(dataCenterDs,dataWarehouseDs);
		Log.info("Sous service soumissionOVO lancé");
	
		Log.info("Sous service recupLog lancé");
	
		majSoldeOVO = new MajAnnulSoldeOVO();
		Log.info("Sous service MajSoldeOVO lancé");
	
		soumissionRep = new SoumissionRep();
		Log.info("Sous service SoumissionRep lancé");
	
		Log.info("Sous services initialisés");
		
		Log.info("Acces Base de donnees TAG");
		System.out.println("Acces Base de donnees TAG");
		this.listTypeOeration = dao.findAllTagTypeOperation();
		Log.info(this.listTypeOeration.size());
    }

    public Envelope process(Envelope envelope) throws ParsingException {
    	
    	Log.info("Acces Base de donnees TAG");
    	System.out.println("Acces Base de donnees TAG");
    	//this.listTypeOeration = dao.findAllTagTypeOperation();
    	System.out.println("Le nombre des operations: "+this.listTypeOeration.size());
    	for( TagTypeOperation typeOperation: this.listTypeOeration ) {
    		System.out.println("Type Operation: "+typeOperation.getCodeOperation());
    	}
    	
    	System.out.println("Le nombre des controles: "+this.listTypeOeration.get(0).getTagControleComptes().size());
    	
	Log.initLogTraceInfos(envelope);
	Date datedebut = new Date();
	Log.info("*   Début de proccess(Envolope)   *\n");

	Log.info("Flux en Entrée:\n" + Outils.prettyPrintEnv(envelope) + "\n\n");

	fluxSortie = new FluxSortie();
	try {
	    parseFluxEntree(envelope);
	} catch (ParsingException ex) {
	    fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREERRTECHNIQUE);
	    fluxSortie.setCodRetScd(CodeRetour.CODSCDEXCEPTION);
	    fluxSortie.setMsgErrMet(CodeRetour.MSGEXCEPTION + " " + ex);
	    Log.error("Erreur  " + ex.getMessage(), ex);
	} catch (Exception e) {
	    fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREERRTECHNIQUE);
	    fluxSortie.setCodRetScd(CodeRetour.CODSCDNULL);
	    fluxSortie.setMsgErrMet(CodeRetour.MSGERRNULL);
	    Log.error("Erreur NullPointerException " + e.getMessage(), e);
	}

	Log.info("ID FONCTION : " + idFonction);
	Envelope envSort = null;

	if ("".equals(idFonction)) {
	    fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREFLUXINVALIDE);
	    fluxSortie.setCodRetScd(CodeRetour.CODSCDCHAMPABSENT);
	    fluxSortie.setMsgErrMet(CodeRetour.MSGCHAMPABSENT + "EVT_COD_FONC");
	    Log.error("Flux d'entree invalide: code fonction vide ou null");
	} else {
	    boolean itsOK = false;
	    try {
		switch (Integer.parseInt(idFonction)) {
		    case CodeFonction.OVODETEC:
			this.comsommateurService = 0;
			Log.info("Code fonction = OVODETEC");
			fluxSortie = controleRisques.traiterRequete(fluxEntree, fluxSortie);
			break;
		    case CodeFonction.OVOSOUMI:
			this.comsommateurService = 0;
			Log.info("Code fonction = OVOSOUMI");
			fluxSortie = soumissionOVO.traiterRequete(envelope, fluxSortie);
			break;
		    case CodeFonction.MAJSOVO02:
			this.comsommateurService = 0;
			Log.info("Code fonction = MAJSOVO002");
			fluxSortie = majSoldeOVO.traiterRequete(envelope, fluxSortie);
			break;
		    case CodeFonction.MAJSOVO:
			this.comsommateurService = 0;
			Log.info("Code fonction = MAJSOVO001");
			fluxSortie = majSoldeOVO.traiterRequete(envelope, fluxSortie);
			break;
		    case CodeFonction.M1001:
			this.comsommateurService = 1; //OVO appelle
			Log.info("Code fonction = M1001");
			fluxSortie = soumissionRep.traiterRequete(envelope, fluxSortie);
			break;
		    case CodeFonction.OTHER:
			this.comsommateurService = 0;
			Log.info("Code fonction Vide!");
			fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREFLUXINVALIDE);
			fluxSortie.setCodRetScd(CodeRetour.CODSCDCHAMPABSENT);
			fluxSortie.setMsgErrMet(CodeRetour.MSGCHAMPABSENT + "COD_FONC");
			break;
		    default:
			this.comsommateurService = 0;
			Log.info("Code fonction = DEFAULT CASE");
			fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREFLUXINVALIDE);
			fluxSortie.setCodRetScd(CodeRetour.CODSCDFONCTIONINEXISTANTE);
			fluxSortie.setMsgErrMet(CodeRetour.MSGFONCTIONINEXISTANTE);
			break;
		}
		itsOK = true;
	    } catch (SQLException e) {
		// erreur innatendue
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREERRTECHNIQUE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDSQLEXCEPTION);
		fluxSortie.setMsgErrMet(CodeRetour.MSGSQLEXCEPTION);
		Log.error("SQLException : " + e.getMessage(), e);
	    } catch (ServiceSoldeException sse) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREEXCEPTIONSERVICEEXTERNE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDEXCEPTIONSOLDE);
		fluxSortie.setMsgErrMet(CodeRetour.MSGEXCEPTIONSOLDE + sse.getMessageErreur());
		Log.error("ServiceSoldeException " + sse.getMessage(), sse);
	    } catch (ServiceSoldeInaccessible ex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREEXCEPTIONSERVICEEXTERNE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDINACCESSIBLESOLDE);
		fluxSortie.setMsgErrMet(CodeRetour.MSGINACCESSIBLESOLDE);
		Log.error("ServiceSoldeInaccessible " + ex.getMessage(), ex);
	    } catch (ServiceOVOInaccessible ex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREEXCEPTIONSERVICEEXTERNE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDINACCESSIBLEOVO);
		fluxSortie.setMsgErrMet(CodeRetour.MSGINACCESSIBLEOVO);
		Log.error("ServiceOVOInaccessible :" + ex.getMessage(), ex);
	    } catch (ServiceOVOException sse) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREEXCEPTIONSERVICEEXTERNE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDEXCEPTIONOVO);
		fluxSortie.setMsgErrMet(CodeRetour.MSGEXCEPTIONOVO + sse.getMessage());
		Log.error("ServiceOVOException " + sse.getMessage(), sse);
	    } catch (ServiceTagException sse) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREEXCEPTIONSERVICEEXTERNE);
		fluxSortie.setCodRetScd(sse.getCodeErreur());
		fluxSortie.setMsgErrMet(CodeRetour.MSGEXCEPTIONTAG + sse.getMessageErreur());
		Log.error("ServiceTAGException " + sse.getMessage(), sse);
	    } catch (ServiceTagInaccessible sse) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREEXCEPTIONSERVICEEXTERNE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDINACCESSIBLETAG);
		fluxSortie.setMsgErrMet(CodeRetour.MSGINACCESSIBLETAG);
		Log.error("ServiceTagInaccessible " + sse.getMessage(), sse);
	    } catch (NumberFormatException nex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREERRTECHNIQUE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDEXCEPTION);
		fluxSortie.setMsgErrMet(CodeRetour.MSGEXCEPTION);
		Log.error("NumberFormatException " + nex.getMessage(), nex);
	    } catch (SoumissionException ex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREERRFONCTIONNELLE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDMANQUERISQUEDECAI);
		fluxSortie.setMsgErrMet(CodeRetour.MSGMANQUERISQUEDECAI);
		Log.error("SoumissionException " + ex.getMessage(), ex);
	    } catch (FormatNumcompteInvalideException ex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREERRTECHNIQUE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDEXCEPTION);
		fluxSortie.setMsgErrMet("Numero de compte incorrect");
		Log.error("FormatNumcompteInvalideException " + ex.getMessage(), ex);
	    } catch (TacheEcouteException ex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREDONNEES);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDTACHEECOUTE);
		fluxSortie.setMsgErrMet(CodeRetour.MSGTACHEECOUTE);
		Log.error("Exception Tache d'ecoute " + ex.getMessage(), ex);
	    } catch (AsalException ex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREEXCEPTIONSERVICEEXTERNE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDEXCEPTIONASAL);
		fluxSortie.setMsgErrMet(CodeRetour.MSGEXCEPTIONASAL);
		Log.error("Exception Générale " + ex.getMessage(), ex);
	    } catch (Exception ex) {
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREERRTECHNIQUE);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDEXCEPTION);
		fluxSortie.setMsgErrMet(CodeRetour.MSGEXCEPTION);
		Log.error("Exception Generale " + ex.getMessage(), ex);
	    } finally {

		if (!itsOK) {
		    sctx.setRollbackOnly();
		    Log.error("Transaction rolled back.");
		}
		try {
		    Log.info("Construction du flux ...");
		    envSort = construireFluxSortie();
		} catch (Exception ex) {
		    Log.error("Une exception est survenue dans finally! : " + ex.getMessage(), ex);
		    String codeRetPrm = this.racineRetour.equalsIgnoreCase("GUFR2B") ? "RET_CODE" : "COD_RET_PRIMAIRE";
		    String codeRetSec = this.racineRetour.equalsIgnoreCase("GUFR2B") ? "COD_RET_SCD" : "COD_RET_SCD";
		    String MsgRetour = this.racineRetour.equalsIgnoreCase("GUFR2B") ? "RET_MESG" : "RET_MSG";

		    String msgTag = ""
			    + "<L T=\".\" N=\"R\">"
			    + "<L T=\".\" N=\"" + this.racineRetour + "\">"
			    + "<L T=\"S\" N=\"" + codeRetPrm + "\">9999</L>"
			    + "<L T=\"S\" N=\"" + codeRetSec + "\">9901</L>"
			    + "<L T=\"S\" N=\"" + MsgRetour + "\">priseOvfgapel00000000 Erreur au moment de construction du flux</L>"
			    + CloseL
			    + CloseL;

		    String msgOvo = ""
			    + "<flux>"
			    + "<entete>"
			    + "<codeErreur>9999</codeErreur>"
			    + "<libErreur>priseOvfgapel00000000 Erreur au moment de construction du flux</libErreur>"
			    + "</entete>"
			    + "</flux>";

		    String msg = (this.comsommateurService == 0) ? msgTag : msgOvo;

		    envSort = new Envelope();

		    envSort.setBody(msg);

		    if (itsOK) {
			sctx.setRollbackOnly();
		    }
		}
		
	    }
	}
	Log.info("*****Flux Retour : ********");

	Log.info(envSort.getBody());

	Log.info("Durée de l'appel du service pour fonction :" + codeFonc + (new Date().getTime() - datedebut.getTime()));
	Log.info("**********Fin appel******************");

	return envSort;
    }

    private void parseFluxEntree(Envelope envelope) throws ParsingException {
	Log.info("Parsing de l'enveloppe ...");

	String racineAller = (envelope.getLNodeAsString("R/GUFQ2K") == null) ? "GUFQ2B" : "GUFQ2K";
	Log.info("Racine aller = " + racineAller);

	racineRetour = racineAller.replace("Q2", "R2");
	Log.info("Racine retour = " + racineRetour);

	codeFonc = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/EVT_COD_FONC")).trim();
	codeFonc = codeFonc.equals("") ? Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/COD_FONC")).trim() : codeFonc;
	codeFonc = codeFonc.equals("") ? Outils.ConvertirEnVideSiNull(envelope.getNodeAsString("flux/entete/idFonction")).trim() : codeFonc;

	fluxEntree = new FluxEntree();
	fluxEntree.setCodFonc(codeFonc);
	fluxEntree.setMntOpe(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/MNT_OPE")));
	fluxEntree.setCodPopsPrd(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/CODE_POPS")));
	if (fluxEntree.getCodPopsPrd().equals("")) {
	    fluxEntree.setCodPopsPrd(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/CODE_POPS")));
	}
	CompteBancaire compte;
	String c = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/RIB_DOR"));
	try {
	    compte = new CompteBancaire(c);
	} catch (CompteIncorrectException ex) {
	    //Log.info(ex.getMessage(), ex);
	    Log.info("Le numero de compte " + c + "n'est ni sur 19 ni sur 24 positions.");
	    compte = null;
	}

	fluxEntree.setRibDor(compte);
	fluxEntree.setCodDevOpe(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/COD_DEV_OPE")));
	fluxEntree.setIdeRibDor(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/IDE_RIB_DOR")));
	fluxEntree.setDevRibDor(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/DEV_RIB_DOR")));
	fluxEntree.setRefTieDorCnc(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/REF_TIE_DOR_CNC")));
	fluxEntree.setRefTieDor(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/REF_TIE_DOR")));
	fluxEntree.setTypCtlRis(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/TYP_CTL_RIS")));
	fluxEntree.setCtlSasDmd(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/CTL_SAS_DMD")));
	fluxEntree.setCodOpe(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/COD_OPE")));
	fluxEntree.setSptOpe(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/SPT_OPE")));
	fluxEntree.setTypOpe(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/TYP_OPE")));
	fluxEntree.setNumTieDorCnc(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/NUM_TIE_DOR_CNC")));
	fluxEntree.setNumTieDor(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/NUM_TIE_DOR")));
	fluxEntree.setNomDor(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/NOM_DOR")));
	fluxEntree.setEvtSopEmet(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/EVT_SOP_EMET")));
	fluxEntree.setEvtUtilLge(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/EVT_UTI_LGE")));
	fluxEntree.setEvtUtiPhy(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/EVT_UTI_PHY")));
	fluxEntree.setEveCodBq(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/EVE_COD_BQ")));
	fluxEntree.setEveCodEntRat(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/EVE_COD_ENT_RAT")));
	fluxEntree.setAgenceCc(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/AGENCE_CC")));
	fluxEntree.setCtgCpt(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/CAT_CPT")));
	fluxEntree.setFlagCltPsg(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/" + racineAller + "/FLAG_CLT_PSG")));

	this.idFonction = CodeFonction.getCodeFunction(fluxEntree.getCodFonc());
	Log.info("Code fonction :" + idFonction);

	Log.info("Fin du Parsing.");
    }

    private Envelope construireFluxSortie() {

	Log.info("Construction du flux sortie ...");
	Envelope envSort = new Envelope();

	//TAG aura le flux en L
	//Zones de codes et message retour :
	String codeRetPrm;
	String codeRetSec;
	String msgRetour;

	if (this.racineRetour.equalsIgnoreCase("GUFR2B")) {
	    codeRetPrm = "RET_CODE";
	    codeRetSec = "COD_RET_SCD";
	    msgRetour = "RET_MESG";
	} else {
	    codeRetPrm = "COD_RET_PRIMAIRE";
	    codeRetSec = "COD_RET_SCD";
	    msgRetour = "RET_MSG";
	}

	StringBuffer s = new StringBuffer("");
	s.append("<L T=\".\" N=\"R\">");
	s.append("<L T=\".\" N=\"" + racineRetour + "\">");

	//Pour OVO, on doit retourner le XML
	String sOVO = ""
		+ "<flux>"
		+ "<entete>";

	String v = fluxSortie.getCodRetPrimaire();

	if (v != null) {

	    s.append("<L T=\"S\" N=\"" + codeRetPrm + "\">" + v + CloseL);

	    sOVO += "<codeErreur>" + v + "</codeErreur>";
	}

	v = fluxSortie.getCodRetScd();
	if (v != null) {
	    s.append("<L T=\"S\" N=\"" + codeRetSec + "\">" + v + CloseL);
	}

	v = fluxSortie.getMsgErrMet();

	if (v != null) {
	    s.append("<L T=\"S\" N=\"" + msgRetour + "\">" + v + CloseL);
	    sOVO += "<libErreur>" + v + "</libErreur>";
	}

	sOVO += "</entete>"
		+ "</flux>";

	if (this.comsommateurService == 1) {
	    envSort.setBody(sOVO);
	    Log.info("Fin de construction du flux de sortie pour OVO");
	    return envSort;
	}
	v = fluxSortie.getGuiOvf();
	if (v != null) {
	    s.append("<L T=\"S\" N=\"GUI_OVF\">" + v + CloseL);
	}
	v = fluxSortie.getDteTvr();
	if (v != null) {
	    s.append("<L T=\"S\" N=\"DTE_TVR\">" + v + CloseL);
	}
	v = fluxSortie.getNbrDte();
	if (v != null) {
	    s.append("<L T=\"N\" N=\"NBR_DTE\">" + v + CloseL);
	}
	v = fluxSortie.getVldManTvr();
	if (v != null) {
	    s.append("<L T=\"S\" N=\"VLD_MAN_TVR\">" + v + CloseL);
	}
	v = fluxSortie.getCtlSasEff();
	if (v != null) {
	    s.append("<L T=\"S\" N=\"CTL_SAS_EFF\">" + v + CloseL);
	}
	v = fluxSortie.getSasAut();
	if (v != null) {
	    s.append("<L T=\"S\" N=\"SAS_AUT\">" + v + CloseL);
	}
	v = fluxSortie.getVldPos();
	if (v != null) {
	    s.append("<L T=\"S\" N=\"VLD_POS\">" + v + CloseL);
	}
	v = fluxSortie.getLrisNbrMax();
	if (v != null) {
	    s.append("<L T=\"N\" N=\"LRIS_NBR_MAX\">" + v + CloseL);
	}
	v = fluxSortie.getLrisNbrOcc();
	if (v != null) {
	    s.append("<L T=\"N\" N=\"LRIS_NBR_OCC\">" + v + CloseL);
	}

	List<Risque> risques = fluxSortie.getRisques();
	if (risques != null && !risques.isEmpty()) {
	    s.append("<L T=\".\" N=\"TAB_RIS\">");
	    Iterator it = risques.iterator();
	    while (it.hasNext()) {
		Risque risque = (Risque) it.next();
		s.append("<L T=\".\" N=\"LTAB_RIS\">");
		s.append("<L T=\"S\" N=\"STA_RIS\">" + risque.getStaRis() + CloseL);
		s.append("<L T=\"S\" N=\"FAM_RIS\">" + risque.getFamRis() + CloseL);
		s.append("<L T=\"S\" N=\"TYP_RIS\">" + risque.getTypRis() + CloseL);
		s.append("<L T=\"S\" N=\"SS_TYP_RIS\">" + risque.getSsTypRis() + CloseL);
		s.append("<L T=\"S\" N=\"RIB_RIS\">" + risque.getRibRis() + CloseL);
		s.append("<L T=\"N\" N=\"SEU_FLT\">" + risque.getSeuFlt() + CloseL);
		s.append("<L T=\"N\" N=\"SEU_VLD\">" + risque.getSeuVld() + CloseL);
		s.append("<L T=\"S\" N=\"LIB_RIS\">" + risque.getLibRis() + CloseL);
		s.append("<L T=\"S\" N=\"IFR_RIS\">" + risque.getIfrRis() + CloseL);
		s.append(CloseL);
	    }
	    s.append(CloseL);
	}
	s.append(CloseL);
	s.append(CloseL); //La balise de fin (R)
	envSort.setBody(s.toString());
	Log.info("Fin de construction du flux de sortie pour TAG.");
	return envSort;
    }
}
