/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ma.eai.devbq.ovfgapel.xmlmapping;

import java.util.List;


public class FluxSortie {
					
    private String guiOvf;
    private String dteTvr; //DTE_TVR;
    private String nbrDte; // NBR_DTE;
    private String vldManTvr; //VLD_MAN_TVR;
    private String ctlSasEff; //CTL_SAS_EFF;
    private String sasAut; //SAS_AUT;
    private String vldPos; //VLD_POS;
    private String lrisNbrOcc; //LRIS_NBR_OCC;
    private String lrisNbrMax; //LRIS_NBR_MAX;
    private List<Risque> risques;// RISQUES;
    private String codRetPrimaire; //COD_RET_PRIMAIRE;
    private String codRetScd; //COD_RET_SCD;
    private String msgErrMet; //MSG_ERR_MET;
    									
    public String getCodRetPrimaire() {
	return codRetPrimaire;	
    }

    public void setCodRetPrimaire(String codRetPrimaire) {
	this.codRetPrimaire = codRetPrimaire;
    }

    public String getCodRetScd() {
	return codRetScd;
    }

    public void setCodRetScd(String codRetScd) {
	this.codRetScd = codRetScd;
    }

    public String getCtlSasEff() {
	return ctlSasEff;
    }

    public void setCtlSasEff(String ctlSasEff) {
	this.ctlSasEff = ctlSasEff;
    }

    public String getDteTvr() {
	return dteTvr;
    }

    public void setDteTvr(String dteTvr) {
	this.dteTvr = dteTvr;
    }

    public String getGuiOvf() {
	return guiOvf;
    }

    public void setGuiOvf(String guiOvf) {
	this.guiOvf = guiOvf;
    }

    public String getLrisNbrMax() {
	return lrisNbrMax;
    }

    public void setLrisNbrMax(String lrisNbrMax) {
	this.lrisNbrMax = lrisNbrMax;
    }

    public String getLrisNbrOcc() {
	return lrisNbrOcc;
    }

    public void setLrisNbrOcc(String lrisNbrOcc) {
	this.lrisNbrOcc = lrisNbrOcc;
    }

    public String getMsgErrMet() {
	return msgErrMet;
    }

    public void setMsgErrMet(String msgErrMet) {
	this.msgErrMet = msgErrMet;
    }

    public String getNbrDte() {
	return nbrDte;
    }

    public void setNbrDte(String nbrDte) {
	this.nbrDte = nbrDte;
    }

    public List<Risque> getRisques() {
	return risques;
    }

    public void setRisques(List<Risque> risques) {
	this.risques = risques;
    }

    public String getSasAut() {
	return sasAut;
    }

    public void setSasAut(String sasAut) {
	this.sasAut = sasAut;
    }

    public String getVldManTvr() {
	return vldManTvr;
    }

    public void setVldManTvr(String vldManTvr) {
	this.vldManTvr = vldManTvr;
    }

    public String getVldPos() {
	return vldPos;
    }

    public void setVldPos(String vldPos) {
	this.vldPos = vldPos;
    }
}
