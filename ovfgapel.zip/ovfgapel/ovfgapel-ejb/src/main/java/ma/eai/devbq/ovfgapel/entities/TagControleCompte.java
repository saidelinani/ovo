package ma.eai.devbq.ovfgapel.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the TAG_CONTROLE_COMPTE database table.
 * 
 */
@Entity
@Table(name="TAG_CONTROLE_COMPTE")
@NamedQuery(name="TagControleCompte.findAll", query="SELECT t FROM TagControleCompte t")
public class TagControleCompte implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_CONTROLE_COMPTE_IDCONTROLECOMPTE_GENERATOR", sequenceName="SEQUENCE_TAG_CONTROLE_COMPTE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_CONTROLE_COMPTE_IDCONTROLECOMPTE_GENERATOR")
	@Column(name="ID_CONTROLE_COMPTE")
	private long idControleCompte;

	@Column(name="CODE_CONTROLE")
	private String codeControle;

	@Column(name="LIBELLE_CONTROLE")
	private String libelleControle;

	@Column(name="MONTANT")
	private BigDecimal montant;

	@Column(name="TYPE_CONTROLE")
	private String typeControle;

	@OneToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    @JoinColumn(name = "REF_ID_RISQUE", referencedColumnName = "ID_RISQUE")
	private TagRisque tagRisque;

	@ManyToMany
	@JoinTable(
		name="TAG_TYPE_OPE_CTRL_CMPT"
		, joinColumns={
				@JoinColumn(name="REF_ID_CONTROLE_COMPTE")
			}
		, inverseJoinColumns={
				@JoinColumn(name="REF_ID_TYPE_OPERATION")
			}
		)
	private List<TagTypeOperation> tagTypeOperation;

	public TagControleCompte() {
	}

	public long getIdControleCompte() {
		return this.idControleCompte;
	}

	public void setIdControleCompte(long idControleCompte) {
		this.idControleCompte = idControleCompte;
	}

	public String getCodeControle() {
		return this.codeControle;
	}

	public void setCodeControle(String codeControle) {
		this.codeControle = codeControle;
	}

	public String getLibelleControle() {
		return this.libelleControle;
	}

	public void setLibelleControle(String libelleControle) {
		this.libelleControle = libelleControle;
	}

	public BigDecimal getMontant() {
		return this.montant;
	}

	public void setMontant(BigDecimal montant) {
		this.montant = montant;
	}

	public String getTypeControle() {
		return this.typeControle;
	}

	public void setTypeControle(String typeControle) {
		this.typeControle = typeControle;
	}

	public TagRisque getTagRisque() {
		return this.tagRisque;
	}

	public void setTagRisque(TagRisque tagRisque) {
		this.tagRisque = tagRisque;
	}

	public List<TagTypeOperation> getTagTypeOperation() {
		return tagTypeOperation;
	}

	public void setTagTypeOperation(List<TagTypeOperation> tagTypeOperation) {
		this.tagTypeOperation = tagTypeOperation;
	}

	@Override
	public boolean equals(Object obj) {
		
		if( obj ==null ) return false;
		if( obj == this ) return true;
		
		TagControleCompte controleCompte = (TagControleCompte) obj;
		System.out.println("Equals: "+this.codeControle.equals(controleCompte.codeControle));
		return this.codeControle.equals(controleCompte.codeControle);
	}

	@Override
	public int hashCode() {
		// TODO Auto-generated method stub
		return super.hashCode();
	}
	
	

}