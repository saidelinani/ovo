package ma.eai.devbq.ovfgapel.constantes;

/**
 * Classe où l'on definit les differents codes retour.
 * @author GHANEM
 */
public final class CodeRetour {

    //Sonar dit: Les classes utilitaires ne doivent pas avoir de constructeur par defaut ou public
    private CodeRetour() {
    }
    /**/
    public static final String CODPRIMAIREOK = "0000";
    public static final String CODSCDOK = "0000";
    public static final String MSGOK = "ovfgapel00000000 OK";

    /**/
    public static final String CODPRIMAIREFLUXINVALIDE = "0002";
    public static final String CODSCDCHAMPABSENT = "0021";
    public static final String MSGCHAMPABSENT = "ovfgapel00020021 Champ(s) absent(s) : ";

    /**/
    public static final String CODSCDTAILLECHAMPINCORRECTE = "0022";
    public static final String MSGTAILLECHAMPINCORRECTE = "ovfgapel00020022 Taille de(s) champ(s) incorrecte : ";

    /**/
    public static final String CODSCDVALEURCHAMPINCORRECTE = "0023";
    public static final String MSGVALEURCHAMPINCORRECTE = "ovfgapel00020022 Champ absent : TYP_RIS et/ou valeur incorrecte : LRIS_NBR_OCC.";

    /**/
    public static final String CODSCDFONCTIONINEXISTANTE = "0023";
    public static final String MSGFONCTIONINEXISTANTE = "ovfgapel00020023 Le service demandé n'existe pas.";

    /**/
    public static final String CODPRIMAIREDONNEES = "0006";
    public static final String CODSCDCLIENTINEXISTANT = "0061";
    public static final String MSGCLIENTINEXISTANT = "ovfgape00060061 Aucun client n'a été trouvé sur le datacenter pour le rib donné.";
   
    public static final String CODSCDTACHEECOUTE = "0062";
    public static final String MSGTACHEECOUTE = "ovfgape00060062 Un problème a été rencontré au niveau de la tache d'écoute.";
    
    /**/
    public static final String CODSCDNUMCOMPTEMULTIPLE = "0062";
    public static final String MSGNUMCOMPTEMULTIPLE = "ovfgapel00060062 Le rib correspond à plusieurs clients sur le datacenter.";

    /**/
    public static final String CODPRIMAIREEXCEPTIONSERVICEEXTERNE = "0008";
    public static final String CODSCDEXCEPTIONSOLDE = "0081";
    public static final String MSGEXCEPTIONSOLDE = "gsc00080081 ";
    public static final String CODSCDINACCESSIBLESOLDE = "0082";
    public static final String MSGINACCESSIBLESOLDE = "ovfgapel00080082 Le service solde est actuellement inaccessible.";
    public static final String CODSCDEXCEPTIONOVO = "0083";
    public static final String MSGEXCEPTIONOVO = "ovo00080083 ";
    public static final String CODSCDINACCESSIBLEOVO = "0084";
    public static final String MSGINACCESSIBLEOVO = "ovfgapel00080084 Le service OVO est actuellement inaccessible.";

    //Service Asal :
    public static final String CODSCDEXCEPTIONASAL  = "0085";
    public static final String  MSGEXCEPTIONASAL = "ovfgapel00080084 L'appel du service Asal pour récupération du DA a échoué!";
    /**/
    public static final String CODSCDEXCEPTIONTAG = "0085";
    public static final String MSGEXCEPTIONTAG = "tag00080085 ";
    public static final String CODSCDINACCESSIBLETAG = "0086";
    public static final String MSGINACCESSIBLETAG = "ovfgapel00080086 Le service TAG est actuellement inaccessible.";

    /**/
    public static final String CODPRIMAIREERRTECHNIQUE = "9999";
    public static final String CODSCDEXCEPTION = "9900";
    public static final String MSGEXCEPTION = "ovfgapel99999900 Une erreur est survenue";
    public static final String CODSCDNULL = "9901";
    public static final String MSGERRNULL = "ovfgapel99999901 Une exception technique a été rencontrée.";
    public static final String CODSCDNOTYET = "9902";
    public static final String MSGNOTYET = "ovfgapel99999902 Service non encore implémenté.";
    public static final String CODSCDSQLEXCEPTION = "9903";
    public static final String MSGSQLEXCEPTION = "ovfgapel99999903 PS inaccessible ou introuvable!";

    /**/
    public static final String CODPRIMAIREERRFONCTIONNELLE = "0003";
    public static final String CODSCDMANQUERISQUEDECAI = "0031";
    public static final String MSGMANQUERISQUEDECAI = "ovfgapel00030031 Aucun risque décaissement, soumission à OVO annulée!";
}
