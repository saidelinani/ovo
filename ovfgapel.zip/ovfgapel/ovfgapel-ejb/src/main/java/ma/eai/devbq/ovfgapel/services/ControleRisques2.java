package ma.eai.devbq.ovfgapel.services;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import ma.eai.Account.CompteClient;
import ma.eai.Account.ReferentielCompte;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.ParsingException;
import ma.eai.devbq.ovfgapel.ServiceOVFGAPEL;
import ma.eai.devbq.ovfgapel.constantes.CodeRetour;
import ma.eai.devbq.ovfgapel.dao.IDaoOvfgapel;
import ma.eai.devbq.ovfgapel.entities.TagControleCompte;
import ma.eai.devbq.ovfgapel.entities.TagRisque;
import ma.eai.devbq.ovfgapel.entities.TagTypeOperation;
import ma.eai.devbq.ovfgapel.exceptions.ServiceSoldeException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceSoldeInaccessible;
import ma.eai.devbq.ovfgapel.exceptions.TacheEcouteException;
import ma.eai.devbq.ovfgapel.xmlmapping.FluxEntree;
import ma.eai.devbq.ovfgapel.xmlmapping.FluxSortie;
import ma.eai.devbq.ovfgapel.xmlmapping.Risque;
import ma.eai.devbq.tools.AppelService;
import ma.eai.devbq.tools.CompteBancaire;
import ma.eai.devbq.tools.CompteIncorrectException;
import ma.eai.devbq.tools.Outils;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.integration.Services;
import ma.eai.midw.log.Log;
import ma.eai.refCpt.exeception.ClientInexistantException;
import ma.eai.refCpt.exeception.CompteClotureException;
import ma.eai.refCpt.exeception.CompteEnCompromisException;
import ma.eai.refCpt.exeception.FormatNumcompteInvalideException;

/**
 * La classe représente le sous service de controle de risques
 *
 * @author Lhoussin GHANEM
 *
 */
public class ControleRisques2 {

    private DataSource dataCenterDs;
    private DataSource dataWarehouseDs;
    private ReferentielCompte refCpt;
    private IDaoOvfgapel dao;
    private String messageErreur = "";
    private String codeErreurPrimaire = "";
    private String codeErreurScd = "";
    private static final Long MONTANT_MIN_COMPTE_CARNET = 100000L;
    private static final String OUI = "OUI";
    private static final String NON = "NON";
    private static final long SEUIL_DEPASSEMENT = 30000000; //egal à 30 000 Dhs car montants en millièmes ;)
    private static final long SEUIL_DEPASSEMENT_RCG = 30000000;
    private static final String NUMEROS_COMPTES_INTERDITS = "011780000009210000067735#011780000010210006101958";
    private static final String NUMEROS_COMPTES_INTERDITS_CNSS = "011780000063210006013657#011780000063210006086019#011780000063210006086116";
    private static final String NUMEROS_COMPTES_INTERDITS_PAI_FACT = "#011780000009210000067735#";
    private static final String CATEGORIES_CONTENTIEUX = ",254,";
    private static final String CATEGORIES_VINT = ",254,255,256";
    private static final String COMPTE_MDJS="011780000010210006101958";
    private static final String COMPTE_RECOUVREMENT_FT_HYPOTHECA="011780000009925005040865"; // modif 02/08/2021 Avancenat TAG / « Compte de recouvrement FT HYPOTHECA » 
    private static final String COMPTE_REMEDIAL_MAGAGEMENT="011780000000233205000079"; // modif 30/08/2021 Avancenat TAG / « Compte de recouvrement RM Experts » 
 
    public ControleRisques2(DataSource dataCenterDs, DataSource dataWarehouseDs) {
        this.dataCenterDs = dataCenterDs;
        this.dataWarehouseDs = dataWarehouseDs;
    }

    /**
     * La methode traite la demande du flux xml, ainsi elle récupère les risques
     * qui concernent le compte, pour construire le flux à retourner.
     *
     * @param fluxEntree
     * @param fluxSortie
     * @return
     * @throws SQLException
     * @throws FormatNumcompteInvalideException
     * @throws ServiceSoldeException
     * @throws ServiceSoldeInaccessible
     * @throws ParsingException
     * @throws TacheEcouteException
     */
    public FluxSortie traiterRequete(FluxEntree fluxEntree, FluxSortie fluxSortie)
            throws SQLException,
            FormatNumcompteInvalideException,
            ServiceSoldeException,
            ServiceSoldeInaccessible,
            ParsingException,
            TacheEcouteException,
            CompteIncorrectException {

        Log.info("Début de traitement de la requête ...");
        List<Risque> risques = new ArrayList();

        boolean cloture = false,
                clotureB = false,
                clotureC = false,
                clotureD = false,
                compromis = false,
                transfere = false,
                provisionInsuffisante = false,
                provisionInsuffisanteB = false,
                provisionInsuffisanteCsc = false,
                compteBloque = false,
                saisieArr = false,
                compteSurCarnet = false,
                depassement30000 = false,
                depassementRCG = false;

        boolean compteInexistantSurDatacenter = false;
        //Implémentation de la règle :

        if (this.valider(fluxEntree)) {

            String evtSopEmet, evtUtiLge, evtUtiPhy, eveCodBq, eveCodEntRat;

            evtSopEmet = fluxEntree.getEvtSopEmet();
            evtUtiLge = fluxEntree.getEvtUtilLge();
            evtUtiPhy = fluxEntree.getEvtUtiPhy();
            eveCodBq = fluxEntree.getEveCodBq();
            eveCodEntRat = fluxEntree.getEveCodEntRat();

            CompteBancaire compte = fluxEntree.getRibDor();
            String numeroCompte = compte.getCompte24();
            String codePopsProduit = fluxEntree.getCodPopsPrd();
            String compteGen = "";
            String montantOperation = fluxEntree.getMntOpe();
            String codOp = fluxEntree.getCodOpe();
            String ctgCpt = fluxEntree.getCtgCpt();

            Log.info("Numéro de compte (RIB) :" + numeroCompte);
            Log.info("Compte général :" + compteGen);
            Log.info("Montant Operation :" + montantOperation);
            Log.info("Code operation :" + codOp);
            Log.info("EvtSopEmet :" + evtSopEmet);
            Log.info("EvtUtiLge :" + evtUtiLge);
            Log.info("evtUtiPhy:" + evtUtiPhy);
            Log.info("eveCodBq :" + eveCodBq);
            Log.info("eveCodEntRat :" + eveCodEntRat);
            Log.info("catégorie compte :" + ctgCpt);
            
            TagTypeOperation typeOperation = null;
            for( TagTypeOperation typeOp: ServiceOVFGAPEL.listTypeOeration ) {
            	if(typeOp.getCodeOperation().equals(codOp)) {
            		typeOperation = typeOp;
            		break;
            	}
            }
            
            /*
             *  Verifier si client de passage
             */
            
            System.out.println( "Heeere" );
            System.out.println( "Flag: "+ fluxEntree.getFlagCltPsg());
            System.out.println( "Controle CLT: "+ typeOperation.getTagControleComptes().contains("CLT-PSG"));
            
            if(fluxEntree.getFlagCltPsg().equals(1) && typeOperation.getTagControleComptes().contains(new TagControleCompte())) {
            	TagRisque tagRisque = dao.findRisqueByType("CLT_PSG");
            	// TODO return TagRisque not Risque 
            	System.out.println( tagRisque.getLibRis() );
            }
            
            
            if (!"VIN".equals(codOp.trim().toUpperCase())) {
                Log.info("Catégorie ignorée car opération non VINT");
                ctgCpt = null;
            }
            ctgCpt = ctgCpt == null ? null : ctgCpt.equals("") ? null : ctgCpt;
            if (ctgCpt != null && CATEGORIES_CONTENTIEUX.contains(ctgCpt)) {
                //Si le compte n'est pas en contentieux=compromis crée un risque bloquant new Risque("BLCON") 
                //AJouter ce risque à la liste et retourner le flux sortie.
                try {
                    refCpt = new ReferentielCompte(numeroCompte);
                    refCpt.intialize(dataCenterDs, dataWarehouseDs);
                    CompteClient cpt = refCpt.getCompteClient();
                    if (cpt == null) {
                        throw new ClientInexistantException();
                    }

                    String codeClient = cpt.getCodeClient();
                    Log.info("Code client = " + codeClient);
                    cpt = refCpt.getClient(cpt.getCodeClient());
                    Log.info("Test sur differents risques :");
                    boolean nonCompromis;
                    try {
                        nonCompromis = !cpt.isCompteCompromis();
                    } catch (CompteEnCompromisException ex) {
                        nonCompromis = false;
                    }
                    if (nonCompromis) {
                        Risque risque;
                        risque = new Risque("NON_CONTX");
                        risques.add(risque);

                    }
                } catch (ClientInexistantException ex) {
                    compteInexistantSurDatacenter = true;
                    Log.info(compteInexistantSurDatacenter ? "Client inexistant sur Datacenter!" : "Client existe sur datacenter.");
                    Log.info(ex.getMessage(), ex);
                }

            }
            // DECES CLIENT:
//	    if (compte.getCategorie().equals("323")) {
//		Risque risque = new Risque("DECES");
//		risques.add(risque);
//	    }

            /*  Compte sur carnet :
             Pour un compte sur carnet, le solde  ne doit jamais  etre inferieure à 100 Dhs
             L'algorithme ci-apres consiste a augementer le montant de l'operation par 100 Dhs
             avant de contreler la provision.
             */
            if ("215,491,550".contains(compte.getCategorie())) {
                Log.info("Compte Sur carnet, categorie : " + compte.getCategorie());
                Log.info("Montant :" + fluxEntree.getMntOpe());
                String centreFrais = compte.getCdf();
                String fluxGdp = "<GSC> "
                        + "<COD_FONC>AGCEMIG01</COD_FONC>  "
                        + " <GSCREQUEST> "
                        + " <SIGNONREQUEST> "
                        + "  <EVE_COD_ENT_RAT>" + centreFrais + "</EVE_COD_ENT_RAT> "
                        + "  </SIGNONREQUEST> "
                        + "  </GSCREQUEST> "
                        + " </GSC> ";

                Log.info("Flux aller GDP = " + fluxGdp);
                Envelope envGdp = new Envelope();
                envGdp.setBody(fluxGdp);
                Boolean agMig = true;
                try {
                    Envelope envRetourGdp = ((SynchroneService) Services.find("ServiceSoldeTemp", SynchroneService.class)).process(envGdp);
                    Log.info("Retour GDP :" + envRetourGdp.getBody());
                    String codeRet = envRetourGdp.getNodeAsString("GSC/GSCRSPONSE/RET_CODE");
                    if ("1001".equals(codeRet.trim())) {
                        agMig = false;
                    }
                } catch (Exception e) {
                    Log.info("exception appel GDP :", e);
                }

                Log.info("Ag Mig = " + agMig);
                if (agMig) {
                    String nouveauMontant = ""
                            + (Long.parseLong(fluxEntree.getMntOpe())
                            + MONTANT_MIN_COMPTE_CARNET);
                    fluxEntree.setMntOpe(nouveauMontant);
                }
                Log.info("Montant + " + fluxEntree.getMntOpe());
                montantOperation = fluxEntree.getMntOpe();
                compteSurCarnet = true;
            }

            /**
            |*******************************************************************************************|
            |Opération                                             |Contrôle compte |Contrôle provision |
            |*******************************************************************************************|
            |RET : Retrait                                         |OUI             |OUI                |
            |RED : Retrait déplacé                                 |OUI             |OUI                |
            |VER : Versement (déplacé ou non)                      |OUI             |NON                |
            |RCT : Retrait chèque pour une tierce personne         |OUI             |OUI                |
            |MON : Echange de monnaie client                       |OUI             |NON                |
            |MOD : Echange de monnaie client déplacé               |OUI             |NON                |
            |RCC : Retrait chèque certifié                         |NON             |NON                |
            |RCG : Retrait chèque payable dans tous les guichets   |NON             |NON                |
            |REV : Retrait effet à vue                             |OUI             |OUI                |
            |REA : Retrait effet avalisé                           |NON             |NON                |
            |FAC : Règlement factures (Medi/Oxy)                   |NON             |NON                |
            |FA2 : Règlement factures (Autres)                     |OUI             |NON                |
            |VIN : Versement sur compte interne                    |OUI             |NON                |
            |EXT : Extourne Versement                              |OUI             |NON                |
            |*******************************************************************************************|
             */
            Boolean ctrlRsqCpt = true; //OUI
            Boolean ctrlRsqProvision = true; //OUI
            Boolean ctrlRsqDepassement30000 = false;// modif du 12/05/2014
            Boolean ctrlRsqVersementSurCompteInterdit = false;
            Boolean ctrlRsqFacturePortnet = false; //Ajouté le 23/03/2020 [Télétravail : Confinement Corona Virus]
            Boolean ctrlRsqRetraitSurCompteInterdit = false; // modif 02/08/2021 Avancenat TAG / « Compte de recouvrement FT HYPOTHECA » 
            Boolean ctrlRsqReglementCompteInterdit = false;  // modif 02/08/2021 Avancenat TAG / « Compte de recouvrement FT HYPOTHECA »
            Boolean ctrlRsqReglementAutreCompteInterdit = false;  // modif 24/11/2021 Avenant TAG : Blocage versement espèce TAG sur compte CNSS
            
            if (codOp.equals("RET")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = true; //OUI
                ctrlRsqDepassement30000 = true;//OUI
                ctrlRsqRetraitSurCompteInterdit = true; // modif 02/08/2021 Avancenat TAG / « Compte de recouvrement FT HYPOTHECA » 
            }

            if (codOp.equals("RED")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = true; //OUI
                ctrlRsqDepassement30000 = true;
            }

            if (codOp.equals("VER")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = false;//NON
                ctrlRsqVersementSurCompteInterdit = true;
            }

            if (codOp.equals("RCT")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = true; //OUI
                ctrlRsqDepassement30000 = true;//OUI

            }

            if (codOp.equals("MON")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = false; //NON
            }

            if (codOp.equals("MOD")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = false; //NON
            }

            if (codOp.equals("RCC")) {
                ctrlRsqCpt = false; //NON
                ctrlRsqProvision = false; //NON
            }

            if (codOp.equals("RCG")) {
                ctrlRsqCpt = false; //NON
                ctrlRsqProvision = true; //NON jusqu'au 19/01/2015 : Nouvelle règle (voir mail de Mr Houcine SMAILI sur cette date)
            }

            if (codOp.equals("REV")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = true; //OUI
                ctrlRsqDepassement30000 = true; //OUI
            }

            if (codOp.equals("REA")) {
                ctrlRsqCpt = false; //NON
                ctrlRsqProvision = true; //OUI
            }

            if (codOp.equals("FAC")) {
                ctrlRsqCpt = true; //OUI
                ctrlRsqProvision = false; //NON
                ctrlRsqFacturePortnet = true; //OUI
                ctrlRsqReglementCompteInterdit = true;
                
                // Inversion de la logique, voir mail El houssin GHANEM Lun 06/12/2021
                /*
                 * Si type 3 (autre société ) : code opération ‘FAC’ transmis à OVO 
                 * Sinon : code opération ‘FA2’ transmis à OVO 
                 * Pour un règlement de facture CNSS il est donc normal que TAG fournisse le code ‘FA2’
                 */
                ctrlRsqReglementAutreCompteInterdit = true; 
            }

            if (codOp.equals("FA2")) {
                ctrlRsqCpt = false; //NON
                ctrlRsqProvision = false; //NON
                ctrlRsqFacturePortnet = true; //OUI
                ctrlRsqReglementCompteInterdit = true; // modif 02/08/2021 Avancenat TAG / « Compte de recouvrement FT HYPOTHECA » 
            }

            if (codOp.equals("VIN")) {
                ctrlRsqCpt = true; //NON
                ctrlRsqProvision = false; //NON
            }
            if ("EXT".equals(codOp)){ 
                ctrlRsqCpt = true; //NON
                ctrlRsqProvision = true; //NON
            }

            //Controle versement sur compte CNSS
            if (ctrlRsqVersementSurCompteInterdit) {
                if (this.NUMEROS_COMPTES_INTERDITS.contains(numeroCompte)) {
                    if (COMPTE_MDJS.equals(numeroCompte)) {
                        risques.add(new Risque("OPERATION-NON-AUTORISEE-MDJS"));
                    } 
                    else {
                    	risques.add(new Risque("OPERATION-NON-AUTORISEE"));
                    }
                }
                else if( this.NUMEROS_COMPTES_INTERDITS_CNSS.contains(numeroCompte) ) {
                	risques.add(new Risque("OPERATION-NON-AUTORISEE-CNSS"));
                }
            }
            if (ctrlRsqFacturePortnet) {
                if (this.NUMEROS_COMPTES_INTERDITS_PAI_FACT.contains(numeroCompte)) {
                    risques.add(new Risque("OPERATION-FACT-PORTNET-NON-AUTORISEE"));
                }
            }
            
            // modif 02/08/2021 Avancenat TAG / « Compte de recouvrement FT HYPOTHECA »
            if( ctrlRsqVersementSurCompteInterdit || ctrlRsqRetraitSurCompteInterdit || ctrlRsqReglementCompteInterdit ) {
            	
            	if(COMPTE_RECOUVREMENT_FT_HYPOTHECA.equals(numeroCompte)) {
                	risques.add(new Risque("OPERATION-NON-AUTORISEE-HYPOTHECA"));
                }
            }
            
            // modif 30/08/2021 Avancenat TAG / « Compte de recouvrement RM Experts »
            if( ctrlRsqVersementSurCompteInterdit || ctrlRsqReglementCompteInterdit ) {
            	
            	if(COMPTE_REMEDIAL_MAGAGEMENT.equals(numeroCompte)) {
                	risques.add(new Risque("OPERATION-NON-AUTORISEE-REMEDIAL-MAGAGEMENT"));
                }
            }
            
            // modif 24/11/2021 Avenant TAG : Blocage versement espèce TAG sur compte CNSS
            if( ctrlRsqReglementAutreCompteInterdit ) {
            	
            	if( this.NUMEROS_COMPTES_INTERDITS_CNSS.contains(numeroCompte) ) {
                	risques.add(new Risque("OPERATION-NON-AUTORISEE-CNSS"));
                }
            }
            
            //Par ALi
            ctrlRsqCpt = ctrlRsqCpt && (ctgCpt == null || !CATEGORIES_CONTENTIEUX.contains(ctgCpt));
            ctrlRsqProvision = ctrlRsqProvision && (ctgCpt == null || !CATEGORIES_CONTENTIEUX.contains(ctgCpt));
            //Controle de risques lies au compte :
            if (ctrlRsqCpt) {
                try {
                    refCpt = new ReferentielCompte(numeroCompte);
                    refCpt.intialize(dataCenterDs, dataWarehouseDs);
                    CompteClient cpt = refCpt.getCompteClient();
                    if (cpt == null) {
                        throw new ClientInexistantException();
                    }
                    String codeClient = cpt.getCodeClient();
                    Log.info("Code client = " + codeClient);
                    cpt = refCpt.getClient(cpt.getCodeClient());
                    Log.info("Test sur differents risques :");

                    //Cloture :
                    String dateCloture = "";
                    cloture = false;
                    try {

                        cloture = cpt.isCompteCloture();
                    } catch (CompteClotureException ex) {

                        cloture = true;
                        if (cpt.getStatutCompte() != null) {
                            if (cpt.getStatutCompte().trim().equalsIgnoreCase("B")) {
                                clotureB = true;
                            } else if (cpt.getStatutCompte().trim().equalsIgnoreCase("D")) {
                                clotureD = true;
                            } else if (cpt.getStatutCompte().trim().equalsIgnoreCase("C")) {
                                clotureC = true;
                            }
                            dateCloture = cpt.getDateCloture();
                        }
                    }
                    Log.info("Cloture ----->:" + ((cloture) ? "OUI " + dateCloture : NON));
                    //Compromis :
                    try {
                        if ("VIN".equals(codOp)) {
                            compromis = false;
                        } else {
                            compromis = cpt.isCompteCompromis();
                        }
                    } catch (CompteEnCompromisException ex) {
                        if ("VIN".equals(codOp)) {
                            compromis = false;
                        } else {
                            compromis = true;
                        }
                    }
                    Log.info("Compromis :" + (compromis ? OUI : NON));
                    CompteClient cpt2;
                    cpt2 = refCpt.checkCompteTransfere(numeroCompte);
                    transfere = cpt2.isTransfere();
                    Log.info("Transfere :" + (transfere ? OUI : NON));
                } catch (ClientInexistantException ex) {
                    compteInexistantSurDatacenter = true;
                    Log.info(compteInexistantSurDatacenter ? "Client inexistant sur Datacenter!" : "Client existe sur datacenter.");
                    Log.info(ex.getMessage(), ex);
                }
            }

            //Contrele de risques lies a la provision :
            if (ctrlRsqProvision) {
                //Provision insuffisante :
                Envelope envelopeRetourSolde = new Envelope();
                try {
                    //Appel du service solde :
                    envelopeRetourSolde = this.ctrlSolde(evtSopEmet, evtUtiLge, evtUtiPhy, eveCodBq, eveCodEntRat, montantOperation, numeroCompte, codePopsProduit, compteGen);
                    if (envelopeRetourSolde == null) {
                        throw new Exception();
                    }
                } catch (ServiceSoldeException ex) {
                    Log.info(ex.getMessage(), ex);
                    throw ex;
                } catch (Exception ex) {
                    Log.error(ex.toString());
                    throw new ServiceSoldeInaccessible(ex);
                }

                String codeRetour = "", msgRetour = "";
                codeRetour = Outils.ConvertirEnVideSiNull(envelopeRetourSolde.getNodeAsString("GSC/GSCRSPONSE/RET_CODE"));
                msgRetour = Outils.ConvertirEnVideSiNull(envelopeRetourSolde.getNodeAsString("GSC/GSCRSPONSE/RET_MESG"));

                //Si le champ n'est pas specifie, on considere que l'agence est migree :
                boolean agenceMigree = true;

                //Commenté le 04/03/2011 après déploiement de toute les agences :
//                if ((envelopeRetourSolde.getNodeAsString("GSC/GSCRSPONSE/AG_MIG") != null)
//                        && (envelopeRetourSolde.getNodeAsString("GSC/GSCRSPONSE/AG_MIG").trim().equals("0"))) {
//                    Log.info("Agence non migree ! !");
//                    agenceMigree = false;
//                }
                //Sinon, on considere que l'agence est migree.
                codeRetour = codeRetour.trim();
                msgRetour = msgRetour.trim();

                if (codeRetour.equals("1000")) {
                    provisionInsuffisante = false;
                }

                if (codeRetour.equals("1030")) {

                    if (agenceMigree) {
                        if (compteSurCarnet) {
                            provisionInsuffisanteCsc = true;
                        } else {
                            provisionInsuffisante = true;
                        }
                    }
                }

                Log.info("Provision insuffisante :" + (provisionInsuffisante ? OUI : NON));
                String blcCompte = "", saisieArret = "";

                blcCompte = Outils.ConvertirEnVideSiNull(envelopeRetourSolde.getNodeAsString("GSC/GSCRSPONSE/SoldeDataReponse/BLC_COMPTE"));
                saisieArret = Outils.ConvertirEnVideSiNull(envelopeRetourSolde.getNodeAsString("GSC/GSCRSPONSE/SoldeDataReponse/SAISIE_ARRET"));

                // CompteBancaire bloque et saisie arret
                // blcCompte = (blcCompte == null) ? "" : blcCompte;
                // saisieArret = (saisieArret == null) ? "" : saisieArret;
                if (agenceMigree) {
                    compteBloque = blcCompte.equals("1");
                    saisieArr = saisieArret.equals("1");
                }

                Log.info("Compte bloque :" + (compteBloque ? OUI : NON));
                Log.info("Saisie arret :" + (saisieArr ? OUI : NON));

                depassement30000 = Long.parseLong(montantOperation.trim()) >= SEUIL_DEPASSEMENT;
                depassementRCG = Long.parseLong(montantOperation.trim()) >= SEUIL_DEPASSEMENT_RCG;

            }

            //Rassemblage des risques :
            if (cloture) {
                if (clotureC) {
                    Risque risque;
                    risque = new Risque("CLOTURE-C");
                    risques.add(risque);
                } else if (clotureB) {
                    Risque risque;
                    risque = new Risque("CLOTURE-B");
                    risques.add(risque);
                } else if (clotureD) {
                    Risque risque;
                    risque = new Risque("CLOTURE-D");
                    risques.add(risque);
                } else {
                    Risque risque;
                    risque = new Risque("CLOTURE");
                    risques.add(risque);
                }
            }

            if (compromis) {
                Risque risque = new Risque("COMPROMIS");
                risques.add(risque);
            }

            if (transfere) {
                Risque risque = new Risque("TRANSFERE");
                risques.add(risque);
            }

            if (compteBloque) {
                Risque risque = new Risque("COMPTE-BLOQUE");
                risques.add(risque);
            }

            if (saisieArr) {
                Risque risque = new Risque("SAISIE-ARRET");
                risques.add(risque);
            }

            if (ctrlRsqDepassement30000 && depassement30000) {
                Risque risque = new Risque("DEPASSEMENT-30000");
                risques.add(risque);
            }

            if (codOp.equals("RCG") && depassementRCG) {
                Risque risque = new Risque("DEPASSEMENT-RCG");
                risques.add(risque);
            }

            //Toute opération de type REA le rique provision insuffisante doit être bloquant
            Boolean provisionInsuffisanteREA = false;
            if ((codOp.equals("REA")) && provisionInsuffisante) {
                provisionInsuffisanteREA = true;
            }

            if (provisionInsuffisanteCsc) {
                Risque risque = new Risque("PROVISION-INSUFFISANTE-CSC");
                risques.add(risque);
            } else if (provisionInsuffisanteREA) {
                Risque risque = new Risque("PROVISION-INSUFFISANTE-REA");
                risques.add(risque);
            } else if (provisionInsuffisanteB) {
                Risque risque = new Risque("PROVISION-INSUFFISANTE-B");
                risques.add(risque);
            } else if (provisionInsuffisante) {
                Risque risque = new Risque("PROVISION-INSUFFISANTE");
                risques.add(risque);
            }

            //Remplissage des donnees du flux sortie :
            fluxSortie.setGuiOvf("O"); //Guichet origine gere sous OVF (O/N)

            fluxSortie.setDteTvr(risques.size() > 0 ? "O" : "N"); //Est-ce queil y a au moins un risque detecte? (O/N)

            fluxSortie.setNbrDte("" + risques.size()); //Nombre de risques detectese?

            fluxSortie.setVldManTvr("N"); //Est-ce queil y a au moins un risque detecte en validation manuelle (O/N)e?

            fluxSortie.setLrisNbrOcc("" + risques.size()); //Nombre deoccurrences dans le tableau TAB_LRIS

            fluxSortie.setCtlSasEff("N"); //Contrele SAS effectue par OVF lors de la detection (O/N)

            fluxSortie.setSasAut("N"); //Utilisateur est habilite e valider manuellement les risques (O/N)

            fluxSortie.setVldPos("N"); //Validation du ou des risques possibles dans leapplication metier (dans notre cas ceest TAG) O/N

            fluxSortie.setLrisNbrMax("25"); //Nombre maximum deoccurrences dans le tableau TAB_LRIS

            fluxSortie.setRisques(risques); //Tableau des risques

            fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREOK);
            fluxSortie.setCodRetScd(CodeRetour.CODSCDOK);
            fluxSortie.setMsgErrMet(CodeRetour.MSGOK);

        } else {
            fluxSortie.setCodRetPrimaire(codeErreurPrimaire);
            fluxSortie.setCodRetScd(codeErreurScd);
            fluxSortie.setMsgErrMet(messageErreur);
        }
        return fluxSortie;
    }

    /**
     * Valide les donnees du flux donne en entree (champ absent, taille
     * incorrecte, etc.)
     *
     * @param fluxEntree
     * @return
     */
    private boolean valider(FluxEntree fluxEntree) {
        Log.info("Validation du flux en cours ...");
        this.messageErreur = "";
        this.codeErreurPrimaire = "";

        String codePopsProduit = fluxEntree.getCodPopsPrd();
        CompteBancaire rib = fluxEntree.getRibDor();
        String mntOp = fluxEntree.getMntOpe();
        String codOp = fluxEntree.getCodOpe();
        String catCpt = fluxEntree.getCtgCpt();

        if ((codePopsProduit == null) || (codePopsProduit.equals(""))) {
            this.codeErreurPrimaire = "0002";

            this.codeErreurScd = "0021";

            this.messageErreur += ((!this.messageErreur.equals("")) ? "\novfgapel00020021 Champ(s) absent(s) :  COD_POPS" : (this.messageErreur.contains("ovfgapel00020021 Champ(s) absent(s) : ")) ? " , COD_POPS" : "ovfgapel00020021 Champ(s) absent(s) :  COD_POPS");
        }

        if ((codOp == null) || (codOp.equals(""))) {
            this.codeErreurPrimaire = "0002";

            this.codeErreurScd = "0021";
            this.messageErreur += ((!this.messageErreur.equals("")) ? "\novfgapel00020021 Champ(s) absent(s) :  COD_OPE" : (this.messageErreur.contains("ovfgapel00020021 Champ(s) absent(s) : ")) ? " , COD_OPE" : "ovfgapel00020021 Champ(s) absent(s) :  COD_OPE");
        }

        if ((!codOp.equalsIgnoreCase("RCC")) && (!codOp.equalsIgnoreCase("RCG")) && (!codOp.equals("REV")) && (!codOp.equals("REA")) && (((mntOp == null) || (mntOp.equals(""))))) {
            this.codeErreurPrimaire = "0002";

            this.codeErreurScd = "0021";
            this.messageErreur += ((!this.messageErreur.equals("")) ? "\novfgapel00020021 Champ(s) absent(s) :  MNT_OPE" : (this.messageErreur.contains("ovfgapel00020021 Champ(s) absent(s) : ")) ? " , MNT_OPE" : "ovfgapel00020021 Champ(s) absent(s) :  MNT_OPE");
        }

        if (rib == null) {
            this.codeErreurPrimaire = "0002";

            this.codeErreurScd = "0022";
            this.messageErreur += ((!this.messageErreur.equals("")) ? "\novfgapel00020022 Taille de(s) champ(s) incorrecte :  RIB_DOR doit etre sur 24" : (this.messageErreur.contains("ovfgapel00020022 Taille de(s) champ(s) incorrecte : ")) ? " , RIB_DOR doit etre sur 24" : "ovfgapel00020022 Taille de(s) champ(s) incorrecte :  RIB_DOR doit etre sur 24");
        }

        if ((mntOp != null) && (!mntOp.equals(""))
                && (mntOp.length() > 18)) {
            this.codeErreurPrimaire = "0002";
            this.codeErreurScd = "0022";
            this.messageErreur += ((!this.messageErreur.equals("")) ? "\novfgapel00020022 Taille de(s) champ(s) incorrecte :  MNT_OP  ne doit pas depasser 18 positions" : (this.messageErreur.contains("ovfgapel00020022 Taille de(s) champ(s) incorrecte : ")) ? " , MNT_OPE ne doit pas depasser 18 positions" : "ovfgapel00020022 Taille de(s) champ(s) incorrecte :  MNT_OP  ne doit pas depasser 18 positions");
        }

        if ("VIN".equals(codOp.trim().toUpperCase())) {
            if (catCpt != null) {
                if (!CATEGORIES_VINT.contains(catCpt)) {
                    this.codeErreurPrimaire = "0002";
                    this.codeErreurScd = "0022";
                    this.messageErreur = "Catégorie invalide pour l'opération VIN  :  " + catCpt;
                }
            } else {
                this.codeErreurPrimaire = "0002";
                this.codeErreurScd = "0022";
                this.messageErreur = "Champ Obligatoire pour l'opération VIN  absent :  CAT_CPT";
            }
        }

        Log.info("Flux " + ((this.codeErreurPrimaire.equals("")) ? "valide" : "invalide"));

        return this.codeErreurPrimaire.equals("");
    }

    /**
     * La methode qui appel le service solde, pour traiter les risques solde.
     *
     * @param montantOperation
     * @param numeroCompte
     * @param codePopsProduit
     * @param compteGen
     * @return
     * @throws ServiceSoldeException
     * @throws Exception
     */
    private Envelope ctrlSolde(String evtSopEmet, String evtUtiLge, String evtUtiPhy, String eveCodBq, String eveCodEntRat, String montantOperation, String numeroCompte, String codePopsProduit, String compteGen)
            throws Exception {

        Envelope envelope;

        Log.info("Appel du service Solde ...");

        String fluxCtrlSolde = getFluxCtrlSolde(evtSopEmet, evtUtiLge, evtUtiPhy, eveCodBq, eveCodEntRat, montantOperation, numeroCompte, codePopsProduit, compteGen);

        //envelope = AppelService.callService("ServiceSoldeTemp", fluxCtrlSolde);
        envelope = AppelService.callService("ServiceSolde", fluxCtrlSolde);
        String codeRetour = "";
        String msgRetour = "";

        codeRetour = Outils.ConvertirEnVideSiNull(envelope.getNodeAsString("GSC/GSCRSPONSE/RET_CODE"));
        msgRetour = Outils.ConvertirEnVideSiNull(envelope.getNodeAsString("GSC/GSCRSPONSE/RET_MESG"));

        Log.info("code retour solde :" + codeRetour);
        Log.info("msg retour solde :" + msgRetour);

        if ((!codeRetour.trim().equals("1000"))
                && (!codeRetour.trim().equals("1030"))
                && (!codeRetour.trim().equals("903"))
                && (!codeRetour.trim().equals("722"))) {
            Log.warn("Le service solde a retourne un flux invalide ! throwing servicesoldeexception ...");

            throw new ServiceSoldeException(codeRetour, msgRetour);

        }

        Log.info(envelope.getBody());
        Log.info("Fin d'appel solde.");

        return envelope;
    }

    public static String getFluxCtrlSolde(String evtSopEmet, String evtUtiLge, String evtUtiPhy, String eveCodBq, String eveCodEntRat, String mntOpe, String rib, String codPops, String cptGen) {
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">"
                + "    <soap:Header/>"
                + "    <soap:Body>"
                + "     <GSC>"
                + "       <COD_FONC>CTRLS0001</COD_FONC>"
                + "        <GSCREQUEST>"
                + "         <SIGNONREQUEST>"
                + "           <EVT_SOP_EMET>" + evtSopEmet + "</EVT_SOP_EMET>"
                + "            <EVT_UTI_LGE>" + evtUtiLge + "</EVT_UTI_LGE>"
                + "            <EVT_UTI_PHY>" + evtUtiPhy + "</EVT_UTI_PHY>"
                + "            <EVE_COD_BQ>" + eveCodBq + "</EVE_COD_BQ>"
                + "            <EVE_COD_CAI>" + eveCodEntRat + "</EVE_COD_CAI>"
                + "         </SIGNONREQUEST>"
                + "          <EVENEMENT>"
                + "           <EVT_DATA_CTRL>"
                + "             <COD_POPS_PRD>" + codPops + "</COD_POPS_PRD>"
                + "              <CPT_GEN>" + cptGen + "</CPT_GEN>"
                + "              <REF_CPT24>" + rib + "</REF_CPT24>"
                + "              <MONT_OPE>" + mntOpe + "</MONT_OPE>"
                + "           </EVT_DATA_CTRL>"
                + "         </EVENEMENT>"
                + "       </GSCREQUEST>"
                + "     </GSC>"
                + "   </soap:Body>"
                + "</soap:Envelope>";
    }

    public Envelope callsolde() throws Exception {
        String evtSopEmet = "";
        String evtUtiLge = "";
        String evtUtiPhy = "";
        String eveCodBq = "";
        String eveCodEntRat = "";
        String rib = "";
        String codPops = "";
        String cptGen = "";

        String body = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
                + "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\">"
                + "    <soap:Header/>"
                + "    <soap:Body>"
                + "     <GSC>"
                + "       <COD_FONC>CSLTS0001</COD_FONC>"
                + "        <GSCREQUEST>"
                + "         <SIGNONREQUEST>"
                + "           <EVT_SOP_EMET>" + evtSopEmet + "</EVT_SOP_EMET>"
                + "            <EVT_UTI_LGE>" + evtUtiLge + "</EVT_UTI_LGE>"
                + "            <EVT_UTI_PHY>" + evtUtiPhy + "</EVT_UTI_PHY>"
                + "            <EVE_COD_BQ>" + eveCodBq + "</EVE_COD_BQ>"
                + "            <EVE_COD_CAI>" + eveCodEntRat + "</EVE_COD_CAI>"
                + "         </SIGNONREQUEST>"
                + "          <EVENEMENT>"
                + "           <EVT_DATA_CTRL>"
                + "             <COD_POPS_PRD>" + codPops + "</COD_POPS_PRD>"
                + "              <CPT_GEN>" + cptGen + "</CPT_GEN>"
                + "              <REF_CPT24>" + rib + "</REF_CPT24>"
                + "           </EVT_DATA_CTRL>"
                + "         </EVENEMENT>"
                + "       </GSCREQUEST>"
                + "     </GSC>"
                + "   </soap:Body>"
                + "</soap:Envelope>";

        Envelope envAller = new Envelope();
        envAller.setBody(body);
        SynchroneService serviceSolde = (SynchroneService) Services.find("PosteAgenceSolde", SynchroneService.class);
        return serviceSolde.process(envAller);
    }
}
