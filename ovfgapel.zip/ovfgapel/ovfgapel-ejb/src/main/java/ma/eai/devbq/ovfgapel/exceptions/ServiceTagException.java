package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author ghanemel
 */
public class ServiceTagException extends Exception {

    private String codeErreur;
    private String messageErreur;

    public String getCodeErreur() {
        return codeErreur;
    }

    public void setCodeErreur(String codeErreur, String msg) {
        this.codeErreur = codeErreur;
        this.messageErreur = msg;
    }

    public String getMessageErreur() {
        return messageErreur;
    }

    public void setMessageErreur(String messageErreur) {
        this.messageErreur = messageErreur;
    }

    public ServiceTagException() {
        super();
    }

    public ServiceTagException(String message) {
        super(message);
    }

    public ServiceTagException(String code, String message) {
        super(message);
        this.codeErreur = code;
        this.messageErreur = message;
    }

    public ServiceTagException(ServiceTagException ex) {
        this.codeErreur = ex.codeErreur;
        this.messageErreur = ex.messageErreur;
    }

    public ServiceTagException(Exception ex) {
        this.messageErreur = ex.getMessage();
    }

    public void setCodeErreur(String cerr) {
        this.codeErreur = cerr;
    }
 
}
