package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author GHANEM
 */
public class TacheEcouteException extends Exception {

    /**
     *
     */
    private static final long serialVersionUID = -4853183258020254388L;
    private String codeErreur;
    private String messageErreur;

    public TacheEcouteException() {
	codeErreur = "";
	messageErreur = "";
    }

    public TacheEcouteException(String codeErreur, String messageErreur) {
	this.codeErreur = codeErreur;
	this.messageErreur = messageErreur;
    }

    public String getCodeErreur() {
	return codeErreur;
    }

    public void setCodeErreur(String codeErreur, String msg) {
	this.codeErreur = codeErreur;
	this.messageErreur = msg;
    }

    public String getMessageErreur() {
	return messageErreur;
    }

    public void setMessageErreur(String messageErreur) {
	this.messageErreur = messageErreur;
    }
}
