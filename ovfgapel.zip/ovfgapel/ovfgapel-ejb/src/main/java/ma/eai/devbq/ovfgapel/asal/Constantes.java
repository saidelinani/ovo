package ma.eai.devbq.ovfgapel.asal;

public final class Constantes {

    private Constantes() {
    }
    public static final String CODE_BANQUE = "02281";
    public static final String CODE_FEDERATION = "35";
    public static final String ASAL_SERVICE_ALIAS = "WEBSERVICE.ASAL_WebServiceAsalAccesseur";
    public static final String GET_INFO_SAS_USR = "ASAL_U_001";
    public static final String GET_INFO_DA = "ASAL_U_012";

}
