package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author ghanemel
 */
public class ServiceSoldeInaccessible extends Exception {

    private String codeErreur;
    private String messageErreur;

    public String getCodeErreur() {
	return codeErreur;
    }

    public void setCodeErreur(String codeErreur, String msg) {
	this.codeErreur = codeErreur;
	this.messageErreur = msg;
    }

    public String getMessageErreur() {
	return messageErreur;
    }

    public void setMessageErreur(String messageErreur) {
	this.messageErreur = messageErreur;
    }

    public ServiceSoldeInaccessible() {
	super();
    }

    public ServiceSoldeInaccessible(String message) {
	super(message);
    }

    public ServiceSoldeInaccessible(String code, String message) {
	super(message);
	this.codeErreur = code;
	this.messageErreur = message;
    }

    public ServiceSoldeInaccessible(Throwable cause) {
	super(cause);
    }

    public ServiceSoldeInaccessible(String message, Throwable cause) {
	super(message, cause);
    }
}
