 /*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ma.eai.devbq.ovfgapel.services;

import javax.naming.NamingException;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.devbq.ovfgapel.constantes.CodeRetour;
import ma.eai.devbq.ovfgapel.exceptions.ServiceOVOException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceOVOInaccessible;
import ma.eai.devbq.ovfgapel.exceptions.ServiceSoldeException;
import ma.eai.devbq.ovfgapel.xmlmapping.FluxSortie;
import ma.eai.devbq.tools.AppelService;
import ma.eai.devbq.tools.Outils;
import ma.eai.dtv.sop.ovo.OVO;
import ma.eai.dtv.sop.ovo.xmlmapping.Operation;
import ma.eai.dtv.sop.ovo.xmlmapping.ParamNatureOperation;
import ma.eai.dtv.sop.ovo.xmlmapping.ParamStatutOperation;
import ma.eai.midw.log.Log;

/**
 *
 * @author GHANEM
 */
public class MajAnnulSoldeOVO {

    private String messageErreur = "";
    private String codeErreurSecondaire = "";
    private String codeErreurPrimaire = "";

    public FluxSortie traiterRequete(Envelope envelope, FluxSortie fluxSortie) throws Exception {

	Log.info("Début de traitement MajAnnulSoldeOVO");
	Log.info("le flux est" + envelope.getBody());

	Operation operation = new Operation();

	// 1 Nature Operation ---------------------------
	ParamNatureOperation pno = new ParamNatureOperation();
	pno.setCodeNature(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_REF_OPE")));
	operation.setParamNatureOperation(pno);

	// 2 Statut Opération---------------------------
	String g = (envelope.getLNodeAsString("R/GUFQ2B/STATUS_OPERATION") == null) ? "" : envelope.getLNodeAsString("R/GUFQ2B/STATUS_OPERATION");
	ParamStatutOperation pso = new ParamStatutOperation();

	pso.setCodeStatut(g);
	operation.setParamStatutOperation(pso);

	// 3 - Id Operation Origine
	String v;

	v = (envelope.getLNodeAsString("R/GUFQ2B/ID_OPERATION_ORIGINE") == null) ? "" : envelope.getLNodeAsString("R/GUFQ2B/ID_OPERATION_ORIGINE");
	operation.setIdOperationOrigine(v);

	operation.setSop(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_SOP_EMET")));

	// le code SAS est fixe en attendant des exemples de flux à fournir par Guillaume
	operation.setCodeSasCC("TAG_"+Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_UTI_LGE")));

//	try {
//	    //Premier événement élémentaire :
//	    String codePops1 = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_ELEMENTAIRE/LEVT_ELEMENTAIRE,1/COD_POPS_PRD")).trim();
//	    String compteGen1 = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_ELEMENTAIRE/LEVT_ELEMENTAIRE,1/CPT_GEN")).trim();
//	    String numCompte1 = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_ELEMENTAIRE/LEVT_ELEMENTAIRE,1/REF_CPT24")).trim();
//
//	    //Deuxième événement élémentaire :
//	    String codePops2 = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_ELEMENTAIRE/LEVT_ELEMENTAIRE,2/COD_POPS_PRD")).trim();
//	    String compteGen2 = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_ELEMENTAIRE/LEVT_ELEMENTAIRE,2/CPT_GEN")).trim();
//	    String numCompte2 = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/EVT_ELEMENTAIRE/LEVT_ELEMENTAIRE,2/REF_CPT24")).trim();
//
//	    //On prend le compte avec code produit et pas de compte général :
//	    if (!codePops1.equals("") && (compteGen1.equals(""))) {
//		operation.setNumCompte(numCompte1);
//	    } else if (!codePops2.equals("") && (compteGen2.equals(""))) {
//		operation.setNumCompte(numCompte2);
//	    } else {
//		operation.setNumCompte("");
//	    }
//	    Log.info("Numéro de compte du client :" + operation.getNumCompte());
//	} catch (Exception ex) {
//	    Log.info("Erreur au moment de lecture du " + ex.getMessage(), ex);
//	}
//
//	String agenceCC = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2B/AGENCE_CC"));

//	//Si le codeCC est null, on soumit au directeur d'agence :
//	Boolean zoneCcVide = operation.getCodeSasCC().equals("");
//	Boolean agenceCcMigree = false;
//	if (!zoneCcVide) {
//	    agenceCcMigree = FonctionsStatiques.isAgenceMigree(agenceCC);
//	}
//
//	Log.info("Zone   cc vide    = " + (zoneCcVide ? "OUI" : "NON"));
//	Log.info("Agence cc Migrée  = " + (agenceCcMigree ? "OUI" : "NON"));
//
//	final int dix = 10;
//	final int douze = 12;
//	final int trois = 3;
//	final int six = 6;
//
//	if (zoneCcVide || (!zoneCcVide && !agenceCcMigree)) {
//	    String guichet = operation.getNumCompte().substring(dix, douze);
//	    String cdf = operation.getNumCompte().substring(trois, six) + guichet;
//	    AsalOutput infoDa = Util.getDACentreFrais(cdf);
//	    operation.setCodeSasCC(infoDa.getCodeSas());
//	    Gestionnaire g2 = new Gestionnaire();
//	    g2.setCodeSas(infoDa.getCodeSas());
//	    g2.setNomGestionnaire(infoDa.getNom() + " " + infoDa.getPrenom());
//	    operation.setGestionnaire(g2);
//	    Log.info("Directeur de l'agence :" + infoDa.getCodeSas() + "#" + infoDa.getNom() + "#" + infoDa.getPrenom());
//	}
        
	operation.setPreEtabli("1");
	if (valider(operation)) {
	    //On transmet directement le flux e Solde :
	    callSolde(envelope);
	    //Puis e OVO si aucune exception n'a ete declenchee :

	    Log.info("Appel OVO...");
	    try {
		OVO.updateStatutOperation(operation.getIdOperationOrigine(),
			operation.getParamNatureOperation().getCodeNature(),
			operation.getParamStatutOperation().getCodeStatut(),
			operation.getCodeSasCC(),
			operation.getSop(),
			operation.getPreEtabli());
		fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREOK);
		fluxSortie.setCodRetScd(CodeRetour.CODSCDOK);
		fluxSortie.setMsgErrMet(CodeRetour.MSGOK);

	    } catch (NamingException ex) {
		throw new ServiceOVOInaccessible(ex);
	    } catch (Exception ex) {
		throw new ServiceOVOException(ex);
	    }
	    Log.info("Fin appel OVO.");
	} else {
	    fluxSortie.setCodRetPrimaire(codeErreurPrimaire);
	    fluxSortie.setCodRetScd(codeErreurSecondaire);
	    fluxSortie.setMsgErrMet(messageErreur);
	}

	Log.info("Fin de traitement MajAnnulSoldeOVO");
	return fluxSortie;
    }

    private boolean valider(Operation operation) {
	Log.info("Validation du flux en cours ...");

	messageErreur = "";
	codeErreurSecondaire = "";
	codeErreurPrimaire = "";

	if ("".equals(operation.getParamNatureOperation().getCodeNature())) {
	    codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
	    codeErreurSecondaire = CodeRetour.CODSCDCHAMPABSENT;
	    messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , EVT_REF_OPE" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " EVT_REF_OPE" : CodeRetour.MSGCHAMPABSENT + " EVT_REF_OPE");
	}
	if ("".equals(operation.getParamStatutOperation().getCodeStatut())) {
	    codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
	    codeErreurSecondaire = CodeRetour.CODSCDCHAMPABSENT;
	    messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , STATUS_OPERATION" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " STATUS_OPERATION" : CodeRetour.MSGCHAMPABSENT + " STATUS_OPERATION");
	}
	if ("".equals(operation.getIdOperationOrigine())) {
	    codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
	    codeErreurSecondaire = CodeRetour.CODSCDCHAMPABSENT;
	    messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , ID_OPERATION_ORIGINE" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " ID_OPERATION_ORIGINE" : CodeRetour.MSGCHAMPABSENT + " ID_OPERATION_ORIGINE");
	}
	if ("".equals(operation.getSop())) {
	    codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
	    codeErreurSecondaire = CodeRetour.CODSCDCHAMPABSENT;
	    messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , EVT_SOP_EMET" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " EVT_SOP_EMET" : CodeRetour.MSGCHAMPABSENT + " EVT_SOP_EMET");
	}

	return codeErreurPrimaire.equals("");
    }

    /*
    private Envelope appelSolde(Envelope envelope){
    return new Envelope();
    }
     */
    private void callSolde(Envelope envlope) throws Exception {

	final String OK = "1000";
	Envelope env;
	String codeRetour = "";

	String msgRetour = "";
	Log.info("Appel du service Solde ...");

	env = AppelService.callService("ServiceSolde", envlope);
	Log.info("Retour solde : \n" + env.getBody());

	codeRetour = Outils.ConvertirEnVideSiNull(env.getLNodeAsString("R/GUFR2B/RET_CODE"));
	msgRetour = Outils.ConvertirEnVideSiNull(env.getLNodeAsString("R/GUFR2B/RET_MESG"));

	if ((!codeRetour.trim().equals(OK))) {
	    Log.warn("Le service solde a retourne un flux invalide !");
	    throw new ServiceSoldeException(codeRetour, msgRetour);
	}
        
	Log.info("Fin appel du service Solde.");
    }
    
}
