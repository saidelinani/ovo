package ma.eai.devbq.ovfgapel.asal;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "root")
public class AsalInput {

	private String service;
	private String codeSas;
	private String codeFede;
	private String codeBanque;
	private String codeGuichet;
	
	public String getService() {
		return service;
	}
	public void setService(String service) {
		this.service = service;
	}
	public String getCodeSas() {
		return codeSas;
	}
	public void setCodeSas(String codeSas) {
		this.codeSas = codeSas;
	}
	public String getCodeFede() {
		return codeFede;
	}
	public void setCodeFede(String codeFede) {
		this.codeFede = codeFede;
	}
	public String getCodeBanque() {
		return codeBanque;
	}
	public void setCodeBanque(String codeBanque) {
		this.codeBanque = codeBanque;
	}

	public String getCodeGuichet() {
		return codeGuichet;
	}

	public void setCodeGuichet(String codeGuichet) {
		this.codeGuichet = codeGuichet;
	}
}