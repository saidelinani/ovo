package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author ghanemel
 */

public class ServiceTagInaccessible extends Exception {

    private String codeErreur;
    private String messageErreur;

    public String getCodeErreur() {
	return codeErreur;
    }

    public void setCodeErreur(String codeErreur, String msg) {
	this.codeErreur = codeErreur;
	this.messageErreur = msg;
    }

    public String getMessageErreur() {
	return messageErreur;
    }

    public void setMessageErreur(String messageErreur) {
	this.messageErreur = messageErreur;
    }

    public ServiceTagInaccessible() {
	super();
    }

    public ServiceTagInaccessible(String message) {
	super(message);
    }

    public ServiceTagInaccessible(String code, String message) {
	super(message);
	this.codeErreur = code;
	this.messageErreur = message;
    }

    public ServiceTagInaccessible(Throwable cause) {
	super(cause);
    }

    public ServiceTagInaccessible(String message, Throwable cause) {
	super(message, cause);
    }
    
}
