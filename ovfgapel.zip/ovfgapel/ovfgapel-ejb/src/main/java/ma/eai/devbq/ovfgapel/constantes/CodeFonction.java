package ma.eai.devbq.ovfgapel.constantes;

/**
 * Classe où l'on definit les differentes fonctions du service ainsi que leurs codes.
 * @author GHANEM
 */
public final class CodeFonction {

    //Sonar dit: Les classes utilitaires ne doivent pas avoir de constructeur par defaut ou public
    private CodeFonction() {
    }

    /**
     * ovoDetec est le code fonction de consultation des risques.
     */
    public static final int OVODETEC = 0;
    /**
     * ovoSoumi est le code fonction d'appel du service OVO.
     */
    public static final int OVOSOUMI = 1;
    /**
     * getLog est le code fonction de consultation des Log de l'application
     * (utilisation interne, sera eliminé après les développements)
     */
    public static final int GETLOG = 2;
    /**
     * majSOvo02 est le code fonction de MAJ SOLDE --> Annulation.
     */
    public static final int MAJSOVO = 4;
    /**
     * OVOSOUMIREP est code fonction de reponse OVO vers Tag
     */
    public static final int MAJSOVO02 = 3;
    /**
     * majSOvo est le code fonction de MAJ SOLDE --> MAJ.
     */
    public static final int M1001 = 5;

    public static final int OTHER = 999;

    /**
     * La methode permet de convertir les codes en chiffres pour pouvoir les traiter dans un switch case.
     * @param codeFonction
     * @return
     */
    public static String getCodeFunction(String codeFonction) {
	codeFonction = codeFonction.trim();
	if (codeFonction.equalsIgnoreCase("OVODETEC")) {
	    return "0";
	}
	if (codeFonction.equalsIgnoreCase("OVOSOUMI")) {
	    return "1";
	}
	if (codeFonction.equalsIgnoreCase("GETLOG")) {
	    return "2";
	}
	if (codeFonction.equalsIgnoreCase("MAJSOVO02")) {
	    return "3";
	}
	if (codeFonction.equalsIgnoreCase("MAJSOVO01")) {
	    return "4";
	}
	if (codeFonction.equalsIgnoreCase("M1001")) {
	    return "5";
	}
	if (codeFonction.equalsIgnoreCase("OVO-SOP-REPONSE")) {
	    return "5";
	}
	return ""+OTHER;
    }
}
