package ma.eai.devbq.ovfgapel.entities;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the TAG_TYPE_OPERATION database table.
 * 
 */
@Entity
@Table(name="TAG_TYPE_OPERATION")
@NamedQuery(name="TagTypeOperation.findAll", query="SELECT t FROM TagTypeOperation t")
public class TagTypeOperation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_TYPE_OPERATION_IDTYPEOPERATION_GENERATOR", sequenceName="SEQUENCE_TAG_TYPE_OPERATION")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_TYPE_OPERATION_IDTYPEOPERATION_GENERATOR")
	@Column(name="ID_TYPE_OPERATION")
	private long idTypeOperation;

	@Column(name="CODE_OPERATION")
	private String codeOperation;

	@Column(name="LIBELLE_OPERATION")
	private String libelleOperation;

	@Column(name="SOP")
	private String sop;

	@OneToMany(mappedBy="tagTypeOperation")
	private List<TagCompteInterdit> tagCompteInterdits;

	@ManyToMany(mappedBy="tagTypeOperation", fetch = FetchType.EAGER)
	private List<TagControleCompte> tagControleComptes;

	@OneToMany(mappedBy="tagTypeOperation")
	private List<TagOperation> tagOperations;

	public TagTypeOperation() {
	}

	public long getIdTypeOperation() {
		return this.idTypeOperation;
	}

	public void setIdTypeOperation(long idTypeOperation) {
		this.idTypeOperation = idTypeOperation;
	}

	public String getCodeOperation() {
		return this.codeOperation;
	}

	public void setCodeOperation(String codeOperation) {
		this.codeOperation = codeOperation;
	}

	public String getLibelleOperation() {
		return this.libelleOperation;
	}

	public void setLibelleOperation(String libelleOperation) {
		this.libelleOperation = libelleOperation;
	}

	public String getSop() {
		return this.sop;
	}

	public void setSop(String sop) {
		this.sop = sop;
	}

	public List<TagCompteInterdit> getTagCompteInterdits() {
		return this.tagCompteInterdits;
	}

	public void setTagCompteInterdits(List<TagCompteInterdit> tagCompteInterdits) {
		this.tagCompteInterdits = tagCompteInterdits;
	}

	public TagCompteInterdit addTagCompteInterdit(TagCompteInterdit tagCompteInterdit) {
		getTagCompteInterdits().add(tagCompteInterdit);
		tagCompteInterdit.setTagTypeOperation(this);

		return tagCompteInterdit;
	}

	public TagCompteInterdit removeTagCompteInterdit(TagCompteInterdit tagCompteInterdit) {
		getTagCompteInterdits().remove(tagCompteInterdit);
		tagCompteInterdit.setTagTypeOperation(null);

		return tagCompteInterdit;
	}

	public List<TagControleCompte> getTagControleComptes() {
		return this.tagControleComptes;
	}

	public void setTagControleComptes(List<TagControleCompte> tagControleComptes) {
		this.tagControleComptes = tagControleComptes;
	}

	public TagControleCompte removeTagControleCompte(TagControleCompte tagControleCompte) {
		getTagControleComptes().remove(tagControleCompte);
		tagControleCompte.setTagTypeOperation(null);

		return tagControleCompte;
	}

	public List<TagOperation> getTagOperations() {
		return this.tagOperations;
	}

	public void setTagOperations(List<TagOperation> tagOperations) {
		this.tagOperations = tagOperations;
	}

	public TagOperation addTagOperation(TagOperation tagOperation) {
		getTagOperations().add(tagOperation);
		tagOperation.setTagTypeOperation(this);

		return tagOperation;
	}

	public TagOperation removeTagOperation(TagOperation tagOperation) {
		getTagOperations().remove(tagOperation);
		tagOperation.setTagTypeOperation(null);

		return tagOperation;
	}

}