package ma.eai.devbq.ovfgapel.entities;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the TAG_OPERATION database table.
 * 
 */
@Entity
@Table(name="TAG_OPERATION")
@NamedQuery(name="TagOperation.findAll", query="SELECT t FROM TagOperation t")
public class TagOperation implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_OPERATION_IDOPERATION_GENERATOR", sequenceName="SEQUENCE_TAG_OPERATION")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_OPERATION_IDOPERATION_GENERATOR")
	@Column(name="ID_OPERATION")
	private long idOperation;

	@Column(name="AGENCE_CC")
	private String agenceCc;

	@Column(name="COD_STA_KYC")
	private String codStaKyc;

	@Column(name="COD_STA_OPE")
	private String codStaOpe;

	@Column(name="CODE_POPS")
	private String codePops;

	@Column(name="CODESAS_CC")
	private String codesasCc;

	@Column(name="DAT_OPE")
	private Date datOpe;

	@Column(name="DAT_SAI")
	private Date datSai;

	@Column(name="DATE_HEURE_FIN_VALIDITE")
	private Date dateHeureFinValidite;

	@Column(name="DEV_RIB_DOR")
	private String devRibDor;

	@Column(name="EVE_COD_ENT_RAT")
	private String eveCodEntRat;

	@Column(name="EVT_UTI_LGE")
	private String evtUtiLge;

	@Column(name="EVT_UTI_PHY")
	private String evtUtiPhy;

	@Column(name="HEU_SAI")
	private String heuSai;

	@Column(name="MNT_OPE")
	private BigDecimal mntOpe;

	@Column(name="NOM_BENEFICIAIRE")
	private String nomBeneficiaire;

	@Column(name="NOM_DOR")
	private String nomDor;

	@Column(name="NUM_TIE_DOR")
	private String numTieDor;

	@Column(name="REF_KYC_PROV")
	private BigDecimal refKycProv;

	@Column(name="REF_OPE")
	private String refOpe;

	@Column(name="REFERENCE_BLOCAGE")
	private String referenceBlocage;

	@Column(name="REFERENCE_OPERATION")
	private String referenceOperation;

	@Column(name="RIB_DOR")
	private String ribDor;

	@OneToOne
	@JoinColumn(name = "REF_ID_CLIENT_PASSAGE", referencedColumnName = "ID_CLIENT_PASSAGE")
	private TagClientPassage tagClientPassage;

	@ManyToOne
	@JoinColumn(name = "REF_ID_TYPE_OPERATION", referencedColumnName = "ID_TYPE_OPERATION")
	private TagTypeOperation tagTypeOperation;

	@ManyToMany(mappedBy="tagOperations")
	private List<TagRisque> tagRisques;

	public TagOperation() {
	}

	public long getIdOperation() {
		return this.idOperation;
	}

	public void setIdOperation(long idOperation) {
		this.idOperation = idOperation;
	}

	public String getAgenceCc() {
		return this.agenceCc;
	}

	public void setAgenceCc(String agenceCc) {
		this.agenceCc = agenceCc;
	}

	public String getCodStaKyc() {
		return this.codStaKyc;
	}

	public void setCodStaKyc(String codStaKyc) {
		this.codStaKyc = codStaKyc;
	}

	public String getCodStaOpe() {
		return this.codStaOpe;
	}

	public void setCodStaOpe(String codStaOpe) {
		this.codStaOpe = codStaOpe;
	}

	public String getCodePops() {
		return this.codePops;
	}

	public void setCodePops(String codePops) {
		this.codePops = codePops;
	}

	public String getCodesasCc() {
		return this.codesasCc;
	}

	public void setCodesasCc(String codesasCc) {
		this.codesasCc = codesasCc;
	}

	public Date getDatOpe() {
		return this.datOpe;
	}

	public void setDatOpe(Date datOpe) {
		this.datOpe = datOpe;
	}

	public Date getDatSai() {
		return this.datSai;
	}

	public void setDatSai(Date datSai) {
		this.datSai = datSai;
	}

	public Date getDateHeureFinValidite() {
		return this.dateHeureFinValidite;
	}

	public void setDateHeureFinValidite(Date dateHeureFinValidite) {
		this.dateHeureFinValidite = dateHeureFinValidite;
	}

	public String getDevRibDor() {
		return this.devRibDor;
	}

	public void setDevRibDor(String devRibDor) {
		this.devRibDor = devRibDor;
	}

	public String getEveCodEntRat() {
		return this.eveCodEntRat;
	}

	public void setEveCodEntRat(String eveCodEntRat) {
		this.eveCodEntRat = eveCodEntRat;
	}

	public String getEvtUtiLge() {
		return this.evtUtiLge;
	}

	public void setEvtUtiLge(String evtUtiLge) {
		this.evtUtiLge = evtUtiLge;
	}

	public String getEvtUtiPhy() {
		return this.evtUtiPhy;
	}

	public void setEvtUtiPhy(String evtUtiPhy) {
		this.evtUtiPhy = evtUtiPhy;
	}

	public String getHeuSai() {
		return this.heuSai;
	}

	public void setHeuSai(String heuSai) {
		this.heuSai = heuSai;
	}

	public BigDecimal getMntOpe() {
		return this.mntOpe;
	}

	public void setMntOpe(BigDecimal mntOpe) {
		this.mntOpe = mntOpe;
	}

	public String getNomBeneficiaire() {
		return this.nomBeneficiaire;
	}

	public void setNomBeneficiaire(String nomBeneficiaire) {
		this.nomBeneficiaire = nomBeneficiaire;
	}

	public String getNomDor() {
		return this.nomDor;
	}

	public void setNomDor(String nomDor) {
		this.nomDor = nomDor;
	}

	public String getNumTieDor() {
		return this.numTieDor;
	}

	public void setNumTieDor(String numTieDor) {
		this.numTieDor = numTieDor;
	}

	public BigDecimal getRefKycProv() {
		return this.refKycProv;
	}

	public void setRefKycProv(BigDecimal refKycProv) {
		this.refKycProv = refKycProv;
	}

	public String getRefOpe() {
		return this.refOpe;
	}

	public void setRefOpe(String refOpe) {
		this.refOpe = refOpe;
	}

	public String getReferenceBlocage() {
		return this.referenceBlocage;
	}

	public void setReferenceBlocage(String referenceBlocage) {
		this.referenceBlocage = referenceBlocage;
	}

	public String getReferenceOperation() {
		return this.referenceOperation;
	}

	public void setReferenceOperation(String referenceOperation) {
		this.referenceOperation = referenceOperation;
	}

	public String getRibDor() {
		return this.ribDor;
	}

	public void setRibDor(String ribDor) {
		this.ribDor = ribDor;
	}

	public TagClientPassage getTagClientPassage() {
		return this.tagClientPassage;
	}

	public void setTagClientPassage(TagClientPassage tagClientPassage) {
		this.tagClientPassage = tagClientPassage;
	}

	public TagTypeOperation getTagTypeOperation() {
		return this.tagTypeOperation;
	}

	public void setTagTypeOperation(TagTypeOperation tagTypeOperation) {
		this.tagTypeOperation = tagTypeOperation;
	}

	public List<TagRisque> getTagRisques() {
		return this.tagRisques;
	}

	public void setTagRisques(List<TagRisque> tagRisques) {
		this.tagRisques = tagRisques;
	}

}