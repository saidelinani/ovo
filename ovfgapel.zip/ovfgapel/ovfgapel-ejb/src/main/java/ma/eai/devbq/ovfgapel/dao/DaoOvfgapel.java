package ma.eai.devbq.ovfgapel.dao;

import java.util.List;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import ma.eai.devbq.ovfgapel.entities.TagRisque;
import ma.eai.devbq.ovfgapel.entities.TagTypeOperation;
import ma.eai.midw.log.Log;

/**
 * @author elinansa
 *
 */
@Stateless(mappedName = "ejb/daoOvfgapel")
@TransactionManagement(value = TransactionManagementType.CONTAINER)
@TransactionAttribute(TransactionAttributeType.REQUIRED)
public class DaoOvfgapel implements IDaoOvfgapel {
	
	@PersistenceContext
    protected EntityManager em;
	
	public EntityManager getEm() {
		return em;
	}


	public void setEm(EntityManager em) {
		this.em = em;
	}
	
	public List<TagTypeOperation> findAllTagTypeOperation() {
		
		Log.info("DEBUT findAllTagTypeOperation");
		String s = "from TagTypeOperation t";
		Query q = em.createQuery(s);
		return q.getResultList();
	}
	
	public TagRisque findRisqueByType(String type) {
		Log.info("DEBUT findRisqueByType");
		String s = "from TagRisque r where r.type = :type";
		Query q = em.createQuery(s);
		q.setParameter("type", type);
		return (TagRisque)q.getSingleResult();
	}
	
}
