package ma.eai.devbq.ovfgapel.services;

import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.ParsingException;
import ma.eai.devbq.ovfgapel.exceptions.FluxInvalide;
import ma.eai.devbq.ovfgapel.exceptions.ServiceTagException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceTagInaccessible;
import ma.eai.devbq.ovfgapel.constantes.CodeRetour;
import ma.eai.devbq.ovfgapel.xmlmapping.FluxSortie;
import ma.eai.devbq.ovfgapel.xmlmapping.RetOVO;
import ma.eai.devbq.tools.AppelService;
import ma.eai.devbq.tools.Outils;
import ma.eai.midw.connectors.SynchroneService;
import ma.eai.midw.log.Log;

/**
 *
 * @author GHANEM
 */
public class SoumissionRep {

    private String messageErreur = "";
    private String codeErreurPrimaire = "";
    private String codeErreurScd = "";

    public FluxSortie traiterRequete(Envelope envelope, FluxSortie fluxSortie)
            throws ParsingException, FluxInvalide, ServiceTagException, ServiceTagInaccessible {

        RetOVO repOvo = new RetOVO();

        repOvo.setIdtOpe(Outils.ConvertirEnVideSiNull(envelope.getNodeAsString("flux/objet/sopUpdateOutput/idOperationOrigine")));

        String statut = Outils.ConvertirEnVideSiNull(envelope.getNodeAsString("flux/objet/sopUpdateOutput/paramStatutOperation/codeStatut"));

        statut = statut.equals("") ? "" : statut.equalsIgnoreCase("REJET") ? "B" : "A";

        repOvo.setCodStaOpe(statut);

        repOvo.setRefBlocage(Outils.ConvertirEnVideSiNull(envelope.getNodeAsString("flux/objet/sopUpdateOutput/refBlocage")));

        repOvo.setIdeLge(envelope.getSasUser());

        if (valider(repOvo)) {

            String fluxL = repOvo.getAsFluxL();

            //On reprend la même envelope reçue
            Envelope aller = envelope;

            //On écrase le body avec l'équivalent L
            aller.setBody(fluxL);

            aller.setPwkType(repOvo.getPwkType()); //1
            aller.setOrigin(repOvo.getOrigin());   //RETRAIT
            aller.setMethod(repOvo.getMethod());   //TSI3309

            Log.info("***************************************");
            Log.info("Utilisateur SAS : " + aller.getSasUser());
            Log.info("PwkType : " + aller.getPwkType());
            Log.info("Method : " + aller.getMethod());
            Log.info("Method : " + aller.getOrigin());
            Log.info("Flux Aller TAG : \n" + aller);
            Log.info("***************************************");

            SynchroneService ss = null;

            // Appel du service TAG
            try {
                //ss = Services.find("SopTuxedo", SynchroneService.class);
                ss = AppelService.lookupServiceRemote("SopTuxedo");

            } catch (Exception ex) {
                throw new ServiceTagInaccessible(ex);
            }

            if (ss == null) {
                throw new ServiceTagInaccessible();
            }

            try {
                Envelope envRetourTag = ss.process(aller);
                Log.info("Flux Retour TAG : " + envRetourTag);

                String codeRetTag = Outils.ConvertirEnVideSiNull(envRetourTag.getLNodeAsString("GUFFRE/COD_RET_PRIMAIRE"));

                if (!codeRetTag.equals("0000")) {
                    String msgRetTag = Outils.ConvertirEnVideSiNull(envRetourTag.getLNodeAsString("GUFFRE/MET_MSG"));
                    System.out.println("Message Retour : " + msgRetTag);
                    throw new ServiceTagException(codeRetTag, msgRetTag);
                }
            } catch (ServiceTagException ex) {

                Log.error("Retour TAG different de 0000   : " + ex.getMessageErreur(), ex);

                throw new ServiceTagException(ex);

            } catch (Exception ex) {

                Log.info("Exception appel du service TAG : " + ex.getMessage(), ex);

                ServiceTagException ste = new ServiceTagException(ex);

                ste.setCodeErreur(CodeRetour.CODSCDEXCEPTIONTAG, "" + ex.getMessage());

                throw ste;

            }

            fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREOK);
            fluxSortie.setCodRetScd(CodeRetour.CODSCDOK);
            fluxSortie.setMsgErrMet(CodeRetour.MSGOK);

        } else {
            fluxSortie.setCodRetPrimaire(codeErreurPrimaire);
            fluxSortie.setCodRetScd(codeErreurScd);
            fluxSortie.setMsgErrMet(messageErreur);
        }

        return fluxSortie;
    }

    private boolean valider(RetOVO repOvo) {
        Log.info("Validation du flux en cours ...");
        messageErreur = "";
        codeErreurPrimaire = "";

        if ("".equals(repOvo.getBlocEme())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , BLOC_EME" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " BLOC_EME" : CodeRetour.MSGCHAMPABSENT + " BLOC_EME");
        }

        if ("".equals(repOvo.getAplEme())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , APL_EME " : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " APL_EME " : CodeRetour.MSGCHAMPABSENT + " APL_EME ");
        }

        if ("".equals(repOvo.getPgmEme())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , PGM_EME" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " PGM_EME" : CodeRetour.MSGCHAMPABSENT + " PGM_EME");
        }

        if ("".equals(repOvo.getTypEme())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , TYP_EME" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " TYP_EME" : CodeRetour.MSGCHAMPABSENT + " TYP_EME");
        }

        if ("".equals(repOvo.getNomEme())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , NOM_EME" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " NOM_EME" : CodeRetour.MSGCHAMPABSENT + " NOM_EME");
        }

        if ("".equals(repOvo.getIdeLge())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , SasUser" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " SasUser" : CodeRetour.MSGCHAMPABSENT + " SasUser");
        }

        if ("".equals(repOvo.getIdePhy())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , IDE_PHY" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " IDE_PHY" : CodeRetour.MSGCHAMPABSENT + " IDE_PHY");
        }

        if ("".equals(repOvo.getModTrt())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , MOD_TRT" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " MOD_TRT" : CodeRetour.MSGCHAMPABSENT + " MOD_TRT");
        }

        if ("".equals(repOvo.getNomFon())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , NOM_FON" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " NOM_FON" : CodeRetour.MSGCHAMPABSENT + " NOM_FON");
        }

        if ("".equals(repOvo.getTypAcn())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , TYP_ACN" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " TYP_ACN" : CodeRetour.MSGCHAMPABSENT + " TYP_ACN");
        }

        if ("".equals(repOvo.getModPar())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , MOD_PAR" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " MOD_PAR" : CodeRetour.MSGCHAMPABSENT + " MOD_PAR");
        }

        if ("".equals(repOvo.getObjGes())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , OBJ_GES" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " OBJ_GES" : CodeRetour.MSGCHAMPABSENT + " OBJ_GES");
        }

        if ("".equals(repOvo.getDatex())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , DATE" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " DATE" : CodeRetour.MSGCHAMPABSENT + " DATE");
        }

        if ("".equals(repOvo.getHeurex())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , HEURE" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " HEURE" : CodeRetour.MSGCHAMPABSENT + " HEURE");
        }

        if ("".equals(repOvo.getPstGrpbque())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , PST_GRPBQE" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " PST_GRPBQE" : CodeRetour.MSGCHAMPABSENT + " PST_GRPBQE");
        }

        if ("".equals(repOvo.getTypMajSta())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , TYP_MAJ_STA" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " TYP_MAJ_STA" : CodeRetour.MSGCHAMPABSENT + " TYP_MAJ_STA");
        }

        if ("".equals(repOvo.getIdtOpe())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , idOperationOrigine" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT
                    + " idOperationOrigine" : CodeRetour.MSGCHAMPABSENT + " idOperationOrigine");
        }

        if ("".equals(repOvo.getCodStaOpe())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , codeStatut" : ((!messageErreur.equals("")) ? "" + CodeRetour.MSGCHAMPABSENT + " codeStatut" : CodeRetour.MSGCHAMPABSENT + " codeStatut");
        }

        if ("A".equalsIgnoreCase(repOvo.getCodStaOpe())
                && "".equals(repOvo.getRefBlocage())) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur
                    += messageErreur.contains(CodeRetour.MSGCHAMPABSENT)
                    ? " , refBlocage puisque codeStatut different de 'REJET'"
                    : ((!messageErreur.equals(""))
                    ? "" + CodeRetour.MSGCHAMPABSENT
                    + " refBlocage puisque codeStatut different de 'REJET'"
                    : CodeRetour.MSGCHAMPABSENT
                    + " refBlocage  puisque codeStatut different de 'REJET'");
        }

        Log.info("Flux " + ((codeErreurPrimaire.equals("")) ? "valide" : "invalide"));
        return codeErreurPrimaire.equals("");
    }
}
