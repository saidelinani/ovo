package ma.eai.devbq.ovfgapel.dao;

import java.util.List;
import ma.eai.devbq.ovfgapel.entities.TagRisque;
import ma.eai.devbq.ovfgapel.entities.TagTypeOperation;

/**
 * @author elinansa
 *
 */
public interface IDaoOvfgapel {

	List<TagTypeOperation> findAllTagTypeOperation();
	TagRisque findRisqueByType(String type);
}
