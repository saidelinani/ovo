package ma.eai.devbq.ovfgapel.exceptions;

/**
 *
 * @author ghanemel
 */

public class FluxInvalide extends Exception {

    private String code;

    public String getCode() {
	return code;
    }

    public void setCode(String code) {
	this.code = code;
    }

    public FluxInvalide() {
	super();
    }

    public FluxInvalide(String message) {
	super(message);
    }

    public FluxInvalide(String message, String code) {
	super(message);
	this.code = code;
    }

    public FluxInvalide(Throwable cause) {
	super(cause);
    }

    public FluxInvalide(String message, Throwable cause) {
	super(message, cause);
    }
    
}
