package ma.eai.devbq.ovfgapel.test;

import java.util.ArrayList;
import java.util.List;

import ma.eai.devbq.ovfgapel.entities.TagControleCompte;

/**
 * @author elinansa
 *
 */
public class Test {

	
	public static void main(String[] args) {
		
		List<TagControleCompte> comptes = new ArrayList<TagControleCompte>();
		
		TagControleCompte tagControleCompte = new TagControleCompte();
		tagControleCompte.setCodeControle("CLT-PSG");
		
		TagControleCompte tagControleCompte2 = new TagControleCompte();
		tagControleCompte2.setCodeControle("COMPTE-BLOQUE");
		
		comptes.add(tagControleCompte);
		comptes.add(tagControleCompte2);
		
		System.out.println(comptes.contains("CLT-PSG"));
		
	}

}
