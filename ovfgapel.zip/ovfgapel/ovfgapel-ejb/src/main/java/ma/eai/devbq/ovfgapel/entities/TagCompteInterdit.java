package ma.eai.devbq.ovfgapel.entities;

import java.io.Serializable;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the TAG_COMPTE_INTERDIT database table.
 * 
 */
@Entity
@Table(name="TAG_COMPTE_INTERDIT")
@NamedQuery(name="TagCompteInterdit.findAll", query="SELECT t FROM TagCompteInterdit t")
public class TagCompteInterdit implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_COMPTE_INTERDIT_IDCOMPTEINTERDIT_GENERATOR", sequenceName="SEQUENCE_TAG_COMPTE_INTERDIT")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_COMPTE_INTERDIT_IDCOMPTEINTERDIT_GENERATOR")
	@Column(name="ID_COMPTE_INTERDIT")
	private long idCompteInterdit;

	@Column(name="LIBELLE_COMPTE")
	private String libelleCompte;

	@Column(name="NUMERO_COMPTE")
	private String numeroCompte;
	
	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "REF_ID_RISQUE", referencedColumnName = "ID_RISQUE")
	private TagRisque tagRisque;

	@OneToOne(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "REF_ID_TYPE_OPERATION", referencedColumnName = "ID_TYPE_OPERATION")
	private TagTypeOperation tagTypeOperation;

	public TagCompteInterdit() {
	}

	public long getIdCompteInterdit() {
		return this.idCompteInterdit;
	}

	public void setIdCompteInterdit(long idCompteInterdit) {
		this.idCompteInterdit = idCompteInterdit;
	}

	public String getLibelleCompte() {
		return this.libelleCompte;
	}

	public void setLibelleCompte(String libelleCompte) {
		this.libelleCompte = libelleCompte;
	}

	public String getNumeroCompte() {
		return this.numeroCompte;
	}

	public void setNumeroCompte(String numeroCompte) {
		this.numeroCompte = numeroCompte;
	}

	public TagRisque getTagRisque() {
		return this.tagRisque;
	}

	public void setTagRisque(TagRisque tagRisque) {
		this.tagRisque = tagRisque;
	}

	public TagTypeOperation getTagTypeOperation() {
		return this.tagTypeOperation;
	}

	public void setTagTypeOperation(TagTypeOperation tagTypeOperation) {
		this.tagTypeOperation = tagTypeOperation;
	}

}