package ma.eai.devbq.ovfgapel.asal;

import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.devbq.ovfgapel.exceptions.AsalException;
import ma.eai.midw.integration.Services;
import ma.eai.midw.integration.http.SynchroneHttp;
import ma.eai.midw.log.Log;

public final class Util {

    private static JAXBContext jaxbContext;
    private static SynchroneHttp service;

    private Util() {
    }

    static {
	service = Services.find(Constantes.ASAL_SERVICE_ALIAS, SynchroneHttp.class);
	try {
	    jaxbContext = JAXBContext.newInstance("ma.eai.devbq.ovfgapel.asal");
	} catch (JAXBException ex) {
	    Log.error(ex.getMessage(), ex);
	}
    }

    public static AsalOutput getDACentreFrais(String centreFrais) throws AsalException {
	AsalInput input = new AsalInput();

	// initialisation
	input.setService(Constantes.GET_INFO_DA);
	input.setCodeBanque(Constantes.CODE_BANQUE);
	input.setCodeFede(Constantes.CODE_FEDERATION);
	input.setCodeGuichet(centreFrais);

	// appel service asal
	String stringResponse;
	
	AsalOutput output;
	try {
	    stringResponse = service.process(prepareFluxEntree(input).toString());
	    // conversion de la réponse
	    output = parseFluxReponse(stringResponse);
	} catch (JAXBException e) {
	    Log.info(e.getMessage(), e);
	    throw new AsalException(e);
	} catch (Exception e) {
	    Log.info(e.getMessage(), e);
	    throw new AsalException(e);
	}
	return output;
    }

    private static AsalOutput parseFluxReponse(String stringResponse) throws JAXBException {

	
    Log.info(" Reponse asal avec flux " + stringResponse);
	

	Unmarshaller unmarshaller = jaxbContext.createUnmarshaller();
	Reader reader = new StringReader(stringResponse);

	return (AsalOutput) unmarshaller.unmarshal(reader);
    }

    private static Envelope prepareFluxEntree(AsalInput asalInput) throws JAXBException {
	Writer writer = new StringWriter();
	Marshaller marshaller = jaxbContext.createMarshaller();
	marshaller.marshal(asalInput, writer);
	String s = writer.toString();
	s = s.substring(s.indexOf("?>") + 2);
	Envelope envSort = new Envelope();
	envSort.setBody(s);
	
    Log.info(" appel asal avec flux " + envSort.toString());
	
	return envSort;
    }

    //    public static void main(String args[]) throws AsalException{
    //	Util.getDACentreFrais(null);
    //	System.out.println("FIIIIIN");
    //    }
}
