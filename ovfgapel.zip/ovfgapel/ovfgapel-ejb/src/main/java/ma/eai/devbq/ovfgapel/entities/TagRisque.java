package ma.eai.devbq.ovfgapel.entities;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;


/**
 * The persistent class for the TAG_RISQUE database table.
 * 
 */
@Entity
@Table(name="TAG_RISQUE")
@NamedQuery(name="TagRisque.findAll", query="SELECT t FROM TagRisque t")
public class TagRisque implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name="TAG_RISQUE_IDRISQUE_GENERATOR", sequenceName="SEQUENCE_TAG_RISQUE")
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="TAG_RISQUE_IDRISQUE_GENERATOR")
	@Column(name="ID_RISQUE")
	private long idRisque;

	@Column(name="TYPE")
	private String type;
	
	@Column(name="FAM_RIS")
	private String famRis;

	@Column(name="IFR_RIS")
	private String ifrRis;

	@Column(name="LIB_RIS")
	private String libRis;

	@Column(name="RIB_RIS")
	private String ribRis;

	@Column(name="SEU_FLT")
	private String seuFlt;

	@Column(name="SEU_VLD")
	private String seuVld;

	@Column(name="SS_TYP_RIS")
	private String ssTypRis;

	@Column(name="STA_RIS")
	private String staRis;

	@Column(name="TYP_RIS")
	private String typRis;

//	@OneToMany(mappedBy="tagRisque")
//	private List<TagCompteInterdit> tagCompteInterdits;
//
//	@OneToMany(mappedBy="tagRisque")
//	private List<TagControleCompte> tagControleComptes;

	@ManyToMany
	@JoinTable(
		name="TAG_OPERATION_RISQUE"
		, joinColumns={
				@JoinColumn(name="REF_ID_RISQUE")
			}
		, inverseJoinColumns={
				@JoinColumn(name="REF_ID_OPERATION")
			}
		)
	private List<TagOperation> tagOperations;

	public TagRisque() {
	}

	public long getIdRisque() {
		return this.idRisque;
	}

	public void setIdRisque(long idRisque) {
		this.idRisque = idRisque;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getFamRis() {
		return this.famRis;
	}

	public void setFamRis(String famRis) {
		this.famRis = famRis;
	}

	public String getIfrRis() {
		return this.ifrRis;
	}

	public void setIfrRis(String ifrRis) {
		this.ifrRis = ifrRis;
	}

	public String getLibRis() {
		return this.libRis;
	}

	public void setLibRis(String libRis) {
		this.libRis = libRis;
	}

	public String getRibRis() {
		return this.ribRis;
	}

	public void setRibRis(String ribRis) {
		this.ribRis = ribRis;
	}

	public String getSeuFlt() {
		return this.seuFlt;
	}

	public void setSeuFlt(String seuFlt) {
		this.seuFlt = seuFlt;
	}

	public String getSeuVld() {
		return this.seuVld;
	}

	public void setSeuVld(String seuVld) {
		this.seuVld = seuVld;
	}

	public String getSsTypRis() {
		return this.ssTypRis;
	}

	public void setSsTypRis(String ssTypRis) {
		this.ssTypRis = ssTypRis;
	}

	public String getStaRis() {
		return this.staRis;
	}

	public void setStaRis(String staRis) {
		this.staRis = staRis;
	}

	public String getTypTis() {
		return this.typRis;
	}

	public void setTypTis(String typRis) {
		this.typRis = typRis;
	}

//	public List<TagCompteInterdit> getTagCompteInterdits() {
//		return this.tagCompteInterdits;
//	}
//
//	public void setTagCompteInterdits(List<TagCompteInterdit> tagCompteInterdits) {
//		this.tagCompteInterdits = tagCompteInterdits;
//	}


//	public List<TagControleCompte> getTagControleComptes() {
//		return this.tagControleComptes;
//	}
//
//	public void setTagControleComptes(List<TagControleCompte> tagControleComptes) {
//		this.tagControleComptes = tagControleComptes;
//	}

	public List<TagOperation> getTagOperations() {
		return this.tagOperations;
	}

	public void setTagOperations(List<TagOperation> tagOperations) {
		this.tagOperations = tagOperations;
	}

}