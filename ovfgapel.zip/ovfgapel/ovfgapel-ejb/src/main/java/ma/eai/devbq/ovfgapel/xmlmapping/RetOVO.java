package ma.eai.devbq.ovfgapel.xmlmapping;

import ma.eai.devbq.tools.Outils;

/**
 *
 * @author GHANEM
 */
public class RetOVO {

    private String pwkType = "1";
    private String method = "RETRAIT";
    private String origin = "TSI3309";
    private String blocEme = "OVO";
    private String aplEme = "OVO";
    private String pgmEme = "TSI3309";
    private String typEme = "IMS";
    private String nomEme = "NY";
    private String ideLge;
    private String idePhy = "PF50-060";
    private String modTrt = "TR";
    private String ideSelBqe = "02281";
    private String ideSelGui = "78016";
    private String ideSelBur = "00";
    private String ideCtxPay = "MA";
    private String nomFon = "M1001";
    private String typAcn = "MOD";
    private String modPar = "L";
    private String objGes = "TAG-OPERATION";
    private String datex = Outils.today("yyyyMMdd");
    private String heurex = Outils.today("hhmmss") + Outils.today("SS").substring(0, 2);
    private String pstFed = "35";
    private String pstBqe = "02281";
    private String pstCai = "78016";
    private String pstBur = "00";
    private String pstGrpbque = "O";
    private String codDevNtn = "MAD";
    //Données variables
    private String typMajSta = "O";
    private String idtOpe;
    private String codStaOpe;
    private String refBlocage;

    public String getAsFluxL() {

	final String CLOSEL="</L>";
	return "<L T=\".\" N=\"R\"> "
		+ "<L T=\".\" N=\"GUFFAL\">"
		+ ((blocEme != null) ? "\n<L T=\"S\" N=\"BLOC_EME\">" + blocEme + CLOSEL : "")
		+ "\n" + "<L T=\"S\" N=\"APL_EME\">" + aplEme + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"PGM_EME\">" + pgmEme + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"TYP_EME\">" + typEme + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"NOM_EME\">" + nomEme + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"IDE_LGE\">" + ideLge + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"IDE_PHY\">" + idePhy + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"MOD_TRT\">" + modTrt + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"IDE_SEL_BQE\">" + ideSelBqe + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"IDE_SEL_GUI\">" + ideSelGui + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"IDE_SEL_BUR\">" + ideSelBur + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"IDE_CTX_PAY\">" + ideCtxPay + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"NOM_FON\">" + nomFon + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"TYP_ACN\">" + typAcn + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"MOD_PAR\">" + modPar + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"OBJ_GES\">" + objGes + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"DATEX\">" + datex + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"HEUREX\">" + heurex + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"PST_FED\">" + pstFed + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"PST_BQE\">" + pstBqe + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"PST_CAI\">" + pstCai + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"PST_BUR\">" + pstBur + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"PST_GRPBQE\">" + pstGrpbque + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"COD_DEV_NTN\">" + codDevNtn + CLOSEL
		+ "\n" + CLOSEL
		+ "\n" + "<L T=\".\" N=\"GUFQ00\">"
		+ "\n" + "<L T=\"S\" N=\"TYP_MAJ_STA\">" + typMajSta + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"IDT_OPE\">" + idtOpe + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"COD_STA_OPE\">" + codStaOpe + CLOSEL
		+ "\n" + "<L T=\"S\" N=\"REF_BLOCAGE\">" + refBlocage + CLOSEL
		+ "\n" + CLOSEL
		+ "\n" + CLOSEL;
    }

    public String getAplEme() {
	return aplEme;
    }

    public void setAplEme(String aplEme) {
	this.aplEme = aplEme;
    }

    public String getBlocEme() {
	return blocEme;
    }

    public void setBlocEme(String blocEme) {
	this.blocEme = blocEme;
    }

    public String getCodDevNtn() {
	return codDevNtn;
    }

    public void setCodDevNtn(String codDevNtn) {
	this.codDevNtn = codDevNtn;
    }

    public String getCodStaOpe() {
	return codStaOpe;
    }

    public void setCodStaOpe(String codStaOpe) {
	this.codStaOpe = codStaOpe;
    }

    public String getDatex() {
	return datex;
    }

    public void setDatex(String datex) {
	this.datex = datex;
    }

    public String getHeurex() {
	return heurex;
    }

    public void setHeurex(String heurex) {
	this.heurex = heurex;
    }

    public String getIdeCtxPay() {
	return ideCtxPay;
    }

    public void setIdeCtxPay(String ideCtxPay) {
	this.ideCtxPay = ideCtxPay;
    }

    public String getIdeLge() {
	return ideLge;
    }

    public void setIdeLge(String ideLge) {
	this.ideLge = ideLge;
    }

    public String getIdePhy() {
	return idePhy;
    }

    public void setIdePhy(String idePhy) {
	this.idePhy = idePhy;
    }

    public String getIdeSelBqe() {
	return ideSelBqe;
    }

    public void setIdeSelBqe(String ideSelBqe) {
	this.ideSelBqe = ideSelBqe;
    }

    public String getIdeSelBur() {
	return ideSelBur;
    }

    public void setIdeSelBur(String ideSelBur) {
	this.ideSelBur = ideSelBur;
    }

    public String getIdeSelGui() {
	return ideSelGui;
    }

    public void setIdeSelGui(String ideSelGui) {
	this.ideSelGui = ideSelGui;
    }

    public String getIdtOpe() {
	return idtOpe;
    }

    public void setIdtOpe(String idtOpe) {
	this.idtOpe = idtOpe;
    }

    public String getMethod() {
	return method;
    }

    public void setMethod(String method) {
	this.method = method;
    }

    public String getModPar() {
	return modPar;
    }

    public void setModPar(String modPar) {
	this.modPar = modPar;
    }

    public String getModTrt() {
	return modTrt;
    }

    public void setModTrt(String modTrt) {
	this.modTrt = modTrt;
    }

    public String getNomEme() {
	return nomEme;
    }

    public void setNomEme(String nomEme) {
	this.nomEme = nomEme;
    }

    public String getNomFon() {
	return nomFon;
    }

    public void setNomFon(String nomFon) {
	this.nomFon = nomFon;
    }

    public String getObjGes() {
	return objGes;
    }

    public void setObjGes(String objGes) {
	this.objGes = objGes;
    }

    public String getOrigin() {
	return origin;
    }

    public void setOrigin(String origin) {
	this.origin = origin;
    }

    public String getPgmEme() {
	return pgmEme;
    }

    public void setPgmEme(String pgmEme) {
	this.pgmEme = pgmEme;
    }

    public String getPstBqe() {
	return pstBqe;
    }

    public void setPstBqe(String pstBqe) {
	this.pstBqe = pstBqe;
    }

    public String getPstBur() {
	return pstBur;
    }

    public void setPstBur(String pstBur) {
	this.pstBur = pstBur;
    }

    public String getPstCai() {
	return pstCai;
    }

    public void setPstCai(String pstCai) {
	this.pstCai = pstCai;
    }

    public String getPstFed() {
	return pstFed;
    }

    public void setPstFed(String pstFed) {
	this.pstFed = pstFed;
    }

    public String getPstGrpbque() {
	return pstGrpbque;
    }

    public void setPstGrpbque(String pstGrpbque) {
	this.pstGrpbque = pstGrpbque;
    }

    public String getPwkType() {
	return pwkType;
    }

    public void setPwkType(String pwkType) {
	this.pwkType = pwkType;
    }

    public String getRefBlocage() {
	return refBlocage;
    }

    public void setRefBlocage(String refBlocage) {
	this.refBlocage = refBlocage;
    }

    public String getTypAcn() {
	return typAcn;
    }

    public void setTypAcn(String typAcn) {
	this.typAcn = typAcn;
    }

    public String getTypEme() {
	return typEme;
    }

    public void setTypEme(String typEme) {
	this.typEme = typEme;
    }

    public String getTypMajSta() {
	return typMajSta;
    }

    public void setTypMajSta(String typMajSta) {
	this.typMajSta = typMajSta;
    }
}
