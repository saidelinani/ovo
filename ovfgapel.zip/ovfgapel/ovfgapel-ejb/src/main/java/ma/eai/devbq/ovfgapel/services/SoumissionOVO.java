package ma.eai.devbq.ovfgapel.services;

import java.text.SimpleDateFormat;
import java.util.Date;
import javax.naming.NamingException;
import javax.sql.DataSource;
import ma.eai.Account.CompteClient;
import ma.eai.Account.ReferentielCompte;
import ma.eai.commons.services.parsing.Envelope;
import ma.eai.commons.services.parsing.ParsingException;
import ma.eai.devbq.ovfgapel.asal.AsalOutput;
import ma.eai.devbq.ovfgapel.asal.Util;
import ma.eai.devbq.ovfgapel.exceptions.FluxInvalide;
import ma.eai.devbq.ovfgapel.exceptions.ServiceOVOException;
import ma.eai.devbq.ovfgapel.exceptions.ServiceOVOInaccessible;
import ma.eai.devbq.ovfgapel.exceptions.SoumissionException;
import ma.eai.devbq.ovfgapel.constantes.CodeRetour;
import ma.eai.devbq.ovfgapel.exceptions.AsalException;
import ma.eai.devbq.ovfgapel.xmlmapping.FluxSortie;
import ma.eai.devbq.tools.Outils;
import ma.eai.dtv.sop.ovo.OVO;
import ma.eai.dtv.sop.ovo.xmlmapping.Gestionnaire;
import ma.eai.dtv.sop.ovo.xmlmapping.Operation;
import ma.eai.dtv.sop.ovo.xmlmapping.ParamNatureOperation;
import ma.eai.dtv.sop.ovo.xmlmapping.ParamStatutOperation;
import ma.eai.midw.log.Log;

/**
 *
 * @author GHANEM
 */
public class SoumissionOVO {

    private String messageErreur = "";
    private String codeErreurPrimaire = "";
    private String codeErreurScd = "";
    private Operation operation = null;
    private String agenceCC;
    private final DataSource dataCenterDs;
    private final DataSource dataWarehouseDs;

    public SoumissionOVO(DataSource dataCenterDs, DataSource dataWarehouseDs) {
        this.dataCenterDs = dataCenterDs;
        this.dataWarehouseDs = dataWarehouseDs;
    }

    /*
     REF_OPE	        	   idOperationOrigine
     DAT_OPE	        	   dateCreation
     COD_OPE	        	   paramNatureOperation.codeNatureOperation
     MNT_OPE	        	   montant
     RIB_DOR	        	   numCompte et te donne aussi ( codeGuichet, codeDevise et codeBanque)
     NUM_TIE_DOR		   idTier
     REFERENCE_OPERATION	   reference
     NOM_BENEFICIAIRE	           beneficiare
     DATE_HEURE_FIN_VALIDITE	   dateValidation
     CODESAS_CC		           codeSasCC
     CODE_POPS		           codePops
     SOP			   sop
     idFonction		           SOPEXTERNE va le figer automatiquement
     NOM_DOR                       nomTier
     */
    public FluxSortie traiterRequete(Envelope envelope, FluxSortie fluxSortie)
            throws ParsingException, ServiceOVOException, ServiceOVOInaccessible, SoumissionException, FluxInvalide, AsalException {

        //On valide d'abord l'opération :
        if (parserValider(envelope)) {
            //Si aucun risque décaissement n'a été détecté, on soumit pas à OVO
//	    String nb = (envelope.getLNodeAsString("R/GUFQ2K/LRIS_NBR_OCC") == null) ? "0" : envelope.getLNodeAsString("R/GUFQ2K/LRIS_NBR_OCC").trim();

//	    int nbrOcc = Integer.parseInt(nb);
//	    Log.info("Nombre de risques - LRIS_NBR_OCC = " + nbrOcc);
//	    Log.info("type premier risque :" + envelope.getLNodeAsString("R/GUFQ2K/TAB_RIS/LTAB_RIS,1/TYP_RIS"));
//	    boolean risqueProvisionInsuffisanteExiste = false;
//
//	    for (int i = 1; i <= nbrOcc; i++) {
//		String typeRisque = "";
//		try {
//		    typeRisque = envelope.getLNodeAsString("R/GUFQ2K/TAB_RIS/LTAB_RIS," + i + "/TYP_RIS").trim();
//		    Log.info("typeRisque :" + typeRisque);
//		} catch (Exception e) {
//		    Log.error("NullPointerException " + e.getMessage(), e);
//		    fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREFLUXINVALIDE);
//		    fluxSortie.setCodRetScd(CodeRetour.CODSCDVALEURCHAMPINCORRECTE);
//		    fluxSortie.setMsgErrMet(CodeRetour.MSGVALEURCHAMPINCORRECTE);
//		    return fluxSortie;
//		}
//
//		Log.info("Type Risque :" + typeRisque);
//
//		if (typeRisque.equals("DECAI")) {
//		    risqueProvisionInsuffisanteExiste = true;
//		    break;
//		}
//	    }
//
//	    if (!risqueProvisionInsuffisanteExiste) {
//		throw new SoumissionException();
//	    }
//
//	    Log.info("Risque Decaissement existe :" + (risqueProvisionInsuffisanteExiste ? "oui" : "non"));
            try {
                Boolean zoneCcVide = operation.getCodeSasCC().equals("");
//                Boolean agenceCcMigree = true;
//                if (!zoneCcVide) {
//                    agenceCcMigree = FonctionsStatiques.isAgenceMigree(agenceCC);
//                }

                // Un CC Fictif commence par le caractère 'Y' :
                Boolean ccFictif = false;
                try {
                    ccFictif = operation.getCodeSasCC().toUpperCase().charAt(0) == 'Y';
                } catch (IndexOutOfBoundsException ex) {
                    ccFictif = false;
                }

                Boolean compteSurCarnet = false;
                if ((operation.getNumCompte().substring(12, 15)).equals("215")
                        || (operation.getNumCompte().substring(12, 15)).equals("491")
                        || (operation.getNumCompte().substring(12, 15)).equals("550")) {
                    compteSurCarnet = true;
                }

                Boolean compteEnDesherence = false;
                ReferentielCompte refCpt = new ReferentielCompte(operation.getNumCompte());
                refCpt.intialize(dataCenterDs, dataWarehouseDs);
                CompteClient cpt = refCpt.getCompteClient();
                compteEnDesherence = cpt.isDesherence();
                Log.info("Zone   cc vide    = " + (zoneCcVide ? "OUI" : "NON"));
                //Log.info("Agence cc Migrée  = " + (agenceCcMigree ? "OUI" : "NON"));
                Log.info("cc Fictif	       = " + (ccFictif ? "OUI" : "NON"));
                //Si le codeCC est null, ou est affecté à une agence non migrée on met le directeur d'agence à sa place :
                Log.info("Compte sur carnet = " + (compteSurCarnet ? "OUI" : "NON"));
                Log.info("Compte en déshérence = " + (compteEnDesherence ? "OUI" : "NON"));

                if (zoneCcVide
                        || //commenté le 04/03/2014
                        // (!zoneCcVide && !agenceCcMigree) ||
                        ccFictif
                        || //Ajouté le 02/02/2016
                        compteSurCarnet
                        || //Ajouté le 08/06/2020
                        compteEnDesherence) {
                    String cdf = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/EVE_COD_ENT_RAT")).trim();
                    AsalOutput infoDa = Util.getDACentreFrais(cdf);
                    Log.info("DA = " + infoDa.getNom() + " " + infoDa.getPrenom());
                    operation.setCodeSasCC(infoDa.getCodeSas());
                    Gestionnaire g = new Gestionnaire();
                    g.setCodeSas(infoDa.getCodeSas());
                    g.setNomGestionnaire(infoDa.getNom() + " " + infoDa.getPrenom());
                    operation.setGestionnaire(g);
                }

                Log.info("Apel du service OVO");
                OVO.ajouterOperation(operation);
                Log.info("Fin appel service OVO");

                fluxSortie.setCodRetPrimaire(CodeRetour.CODPRIMAIREOK);
                fluxSortie.setCodRetScd(CodeRetour.CODSCDOK);
                fluxSortie.setMsgErrMet(CodeRetour.MSGOK);

            } catch (AsalException ex) {
                Log.info("****Exception Asal :");
                Log.info(ex.getMessage(), ex);
                Log.info("****");
                throw ex;
            } catch (NamingException ex) {
                Log.info("****Exception OVO :");
                Log.error(ex.getMessage(), ex);
                throw new ServiceOVOInaccessible(ex);
            } catch (Exception ex) {
                Log.info("****Exception OVO :");
                Log.info(ex.getMessage(), ex);
                Log.info("****");
                throw new ServiceOVOException(ex);
            }
        } else {
            fluxSortie.setCodRetPrimaire(codeErreurPrimaire);
            fluxSortie.setCodRetScd(codeErreurScd);
            fluxSortie.setMsgErrMet(messageErreur);
        }
        return fluxSortie;
    }

    private boolean parserValider(Envelope envelope) throws ParsingException {

        messageErreur = "";
        codeErreurPrimaire = "";
        codeErreurScd = "";

        Log.info("Validation du flux en cours ...");

        operation = new Operation();

        String v;
        v = (envelope.getLNodeAsString("R/GUFQ2K/REF_OPE") == null) ? "" : envelope.getLNodeAsString("R/GUFQ2K/REF_OPE");
        operation.setIdOperationOrigine(v);

        String dt = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/DAT_OPE"));

        String tm = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/HEU_SAI"));

        //Agence du CC :
        agenceCC = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/AGENCE_CC"));

        dt += " " + tm;

        Log.info(dt);
        operation.setDateCreation(dt);

        Long d;
        try {
            Boolean b = (envelope.getLNodeAsString("R/GUFQ2K/MNT_OPE") == null) || (envelope.getLNodeAsString("R/GUFQ2K/MNT_OPE").equals(""));
            v = b ? "" : envelope.getLNodeAsString("R/GUFQ2K/MNT_OPE");

            if (v.equals("")) {
                codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
                codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
                messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , MNT_OPE" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " MNT_OPE" : CodeRetour.MSGCHAMPABSENT + " MNT_OPE");
                v = "0";
            }

            d = Long.parseLong(v);
            v = Outils.MilliemeVersCentieme(d);
            d = Long.parseLong(v);
            operation.setMontant(d);

        } catch (Exception ex) {
            Log.error(ex.getMessage(), ex);
            operation.setMontant(null);
        }

        String numCompte = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/RIB_DOR"));
        operation.setNumCompte(numCompte);

        //Modification du 25/01/2012
        operation.setCodeDevise(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/COD_DEV_OPE")));
        operation.setCodeGuichet(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/EVE_COD_ENT_RAT")));
        operation.setCodeBanque(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/EVE_COD_BQ")));
        //Fin Modification.

        operation.setIdTier(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/NUM_TIE_DOR")));
        operation.setReference(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/REFERENCE_OPERATION")));
        operation.setBeneficiare(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/NOM_BENEFICIAIRE")));

        //Réception date (format : YYYYMMDDHHMM )
        String dtString = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/DATE_HEURE_FIN_VALIDITE"));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmm");
        Date dateValidite = null;
        try {
            dateValidite = sdf.parse(dtString);
            sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            dtString = sdf.format(dateValidite);
        } catch (Exception e) {
            Log.info("Exception au moment du formattage de la date :" + e.getMessage(), e);
            dtString = "";
        }

        //Envoi date (format : yyyy-MM-dd HH:mm:ss)
        operation.setDateValidation(dtString);

        operation.setCodeSasCC(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/CODESAS_CC")));
        operation.setCodePops(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/CODE_POPS")));
        operation.setSop(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/SOP")));

        ParamNatureOperation pno = new ParamNatureOperation();
        pno.setCodeNature(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/COD_OPE")));
        operation.setParamNatureOperation(pno);

        operation.setPreEtabli("1");

        ParamStatutOperation pso = new ParamStatutOperation();
        pso.setCodeStatut("ADECIDER");
        operation.setParamStatutOperation(pso);

        operation.setNomTier(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/NOM_DOR")));

        Gestionnaire g = new Gestionnaire();
        g.setCodeSas(operation.getCodeSasCC());

        if (agenceCC.equals("") && (!operation.getCodeSasCC().equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , AGENCE_CC" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " AGENCE_CC" : CodeRetour.MSGCHAMPABSENT + " AGENCE_CC");
        }

        g.setNomGestionnaire(Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/EVT_UTI_LGE")));
        operation.setGestionnaire(g);

        String idOperationOrigine = operation.getIdOperationOrigine();
        if ((idOperationOrigine == null) || (idOperationOrigine.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , REF_OPE" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " REF_OPE" : CodeRetour.MSGCHAMPABSENT + " REF_OPE");
        }

        String dateCreation = operation.getDateCreation();
        if ((dateCreation == null) || (dateCreation.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , DAT_OPE" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " DAT_OPE" : CodeRetour.MSGCHAMPABSENT + " DAT_OPE");
        }

        try {
            String paramNatureOperation = operation.getParamNatureOperation().getCodeNature();
            if ((paramNatureOperation == null) || (paramNatureOperation.equals(""))) {
                codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
                codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
                messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , COD_OPE" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " COD_OPE" : CodeRetour.MSGCHAMPABSENT + " COD_OPE");
            }
        } catch (Exception ex) {
            Log.error("Exception :" + ex.getMessage(), ex);
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , COD_OPE" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " COD_OPE" : CodeRetour.MSGCHAMPABSENT + " COD_OPE");
        }

        String numCompte2 = operation.getNumCompte();
        if ((numCompte2 == null) || (numCompte2.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , RIB_DOR" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " RIB_DOR" : CodeRetour.MSGCHAMPABSENT + " RIB_DOR");
        }

        String idTier = operation.getIdTier();
        if ((idTier == null) || (idTier.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , NUM_TIE_DOR" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " NUM_TIE_DOR" : CodeRetour.MSGCHAMPABSENT + " NUM_TIE_DOR");
        }

        String reference = operation.getReference();
        if ((reference == null) || (reference.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , REFERENCE_OPERATION" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " REFERENCE_OPERATION" : CodeRetour.MSGCHAMPABSENT + " REFERENCE_OPERATION");
        }

        String beneficiare = operation.getBeneficiare();
        if ((beneficiare == null) || (beneficiare.equals(""))) {

            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , NOM_BENEFICIAIRE" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " NOM_BENEFICIAIRE" : CodeRetour.MSGCHAMPABSENT + " NOM_BENEFICIAIRE");
        }

//	String CodeSasCC = operation.getCodeSasCC();
//	if ((CodeSasCC == null) || (CodeSasCC.equals(""))) {
//	    codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
//	    codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
//	    messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , CODESAS_CC" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " CODESAS_CC" : CodeRetour.MSGCHAMPABSENT + " CODESAS_CC");
//	}
        String codePops = operation.getCodePops();
        if ((codePops == null) || (codePops.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , CODE_POPS" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " CODE_POPS" : CodeRetour.MSGCHAMPABSENT + " CODE_POPS");
        }

        String sop = operation.getSop();
        if ((sop == null) || (sop.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , SOP" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " SOP" : CodeRetour.MSGCHAMPABSENT + " SOP");
        }

        String nomTier = operation.getNomTier();
        if ((nomTier == null) || (nomTier.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , NOM_DOR" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " NOM_DOR" : CodeRetour.MSGCHAMPABSENT + " NOM_DOR");
        }

        String nb = Outils.ConvertirEnVideSiNull(envelope.getLNodeAsString("R/GUFQ2K/LRIS_NBR_OCC")); // == null) ? "0" : envelope.getLNodeAsString("R/GUFQ2K/LRIS_NBR_OCC").trim();
        if ((nb == null) || (nb.equals(""))) {
            codeErreurPrimaire = CodeRetour.CODPRIMAIREFLUXINVALIDE;
            codeErreurScd = CodeRetour.CODSCDCHAMPABSENT;
            messageErreur += messageErreur.contains(CodeRetour.MSGCHAMPABSENT) ? " , LRIS_NBR_OCC" : ((!messageErreur.equals("")) ? "\n" + CodeRetour.MSGCHAMPABSENT + " LRIS_NBR_OCC" : CodeRetour.MSGCHAMPABSENT + " LRIS_NBR_OCC");
        }

        Log.info("Flux " + ((codeErreurPrimaire.equals("")) ? "valide" : "invalide"));
        return codeErreurPrimaire.equals("");
    }
}
